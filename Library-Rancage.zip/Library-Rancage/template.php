<?php
include "session.php";
include "../koneksi.php";

$email = $_SESSION['email'];
$query_user = "SELECT id FROM user WHERE email = '$email'";
$result_user = mysqli_query($koneksi, $query_user);
$user_data = mysqli_fetch_assoc($result_user);
$user_id = $user_data['id'];

// Query untuk mendapatkan histori peminjaman sesuai user yang login
$query = "
    SELECT peminjaman.tgl_pinjam, peminjaman.batas_pinjam, peminjaman.status,
           buku.judul, buku.penulis, buku.penerbit, buku.tahun_terbit, kategoribuku.nama_kategori
    FROM peminjaman
    JOIN buku ON peminjaman.buku_id = buku.id
    JOIN kategoribuku_relasi ON buku.id = kategoribuku_relasi.buku_id
    JOIN kategoribuku ON kategoribuku_relasi.kategori_id = kategoribuku.id
    WHERE peminjaman.user_id = '$user_id'
    ORDER BY peminjaman.tgl_pinjam DESC";

$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>Histori Peminjaman</title>
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet">
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet">
</head>

<body class="">
  <div class="wrapper">
    <!-- Sidebar -->
    <div class="sidebar" data-color="white" data-active-color="danger">
      <div class="logo">
        <a href="dashboard_user.php" class="simple-text logo-normal">Library Rancage</a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li><a href="./dashboard.php"><i class="nc-icon nc-bank"></i>
              <p>Beranda</p>
            </a></li>
          <li><a href="./buku.php"><i class="nc-icon nc-book-bookmark"></i>
              <p>Daftar Buku</p>
            </a></li>
          <li class="active"><a href="./peminjaman.php"><i class="nc-icon nc-badge"></i>
              <p>Histori Peminjaman</p>
            </a></li>
          <li><a href="./ulasan.php"><i class="nc-icon nc-chat-33"></i>
              <p>Ulasan Anda</p>
            </a></li>
          <li><a href="./user.php"><i class="nc-icon nc-single-02"></i>
              <p>Profile</p>
            </a></li>
          <li><a href="./logout.php"><i class="nc-icon nc-button-power"></i>
              <p>Logout</p>
            </a></li>
        </ul>
      </div>
    </div>

    <!-- Main Panel -->
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;">Histori Peminjaman</a>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->

      <div class="content">
        <div class="container">
          <div class="row">
            <?php while ($row = mysqli_fetch_assoc($result)) : ?>
              <div class="col-md-12 col-lg-8 mb-4">
                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title"><?php echo $row['judul']; ?></h5>
                    <p class="card-text">
                      <strong>Kategori:</strong> <?php echo $row['nama_kategori']; ?><br>
                      <strong>Penulis:</strong> <?php echo $row['penulis']; ?><br>
                      <strong>Penerbit:</strong> <?php echo $row['penerbit']; ?><br>
                      <strong>Tahun Terbit:</strong> <?php echo $row['tahun_terbit']; ?><br>
                      <strong>Tanggal Pinjam:</strong> <?php echo $row['tgl_pinjam']; ?><br>
                      <strong>Batas Pinjam:</strong> <?php echo $row['batas_pinjam']; ?><br>
                      <strong>Status:</strong> <?php echo $row['status']; ?>
                    </p>
                    <?php if ($row['status'] === 'dikembalikan') : ?>
                      <a href="tambah_ulasan.php?buku_id=<?php echo $row['buku_id']; ?>" class="btn btn-warning mt-3">Tambah Ulasan</a>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            <?php endwhile; ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Core JS Files -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
</body>

</html>