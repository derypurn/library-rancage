<?php
include "../koneksi.php";
include "session.php";

// Ambil data user untuk dropdown
$query_users = "SELECT id, namalengkap FROM user";
$result_users = mysqli_query($koneksi, $query_users);

// Ambil data buku untuk dropdown
$query_books = "SELECT id, judul FROM buku";
$result_books = mysqli_query($koneksi, $query_books);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $buku_id = $_POST['buku_id'];
    $tgl_pinjam = date("Y-m-d"); // Tanggal pinjam hari ini
    $batas_pinjam = date("Y-m-d", strtotime("+7 days")); // Batas pinjam 7 hari dari hari ini

    // Insert data ke tabel peminjaman
    $query = "INSERT INTO peminjaman (user_id, buku_id, tgl_pinjam, batas_pinjam, tgl_kembali, status) 
              VALUES ('$user_id', '$buku_id', '$tgl_pinjam', '$batas_pinjam', NULL, 'dipinjam')";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Peminjaman berhasil ditambahkan!'); window.location.href='peminjaman.php';</script>";
    } else {
        echo "<script>alert('Gagal menambah data peminjaman.'); window.history.back();</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        PERPUSTAKAAN RANCAGE
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="../assets/demo/demo.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4>Tambah Peminjaman</h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="mb-3">
                                <label for="user_id" class="form-label">Nama Lengkap</label>
                                <select class="form-control" id="user_id" name="user_id" required>
                                    <option value="" disabled selected>Pilih User</option>
                                    <?php while ($user = mysqli_fetch_assoc($result_users)) : ?>
                                        <option value="<?= $user['id'] ?>"><?= $user['namalengkap'] ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="buku_id" class="form-label">Buku</label>
                                <select class="form-control" id="buku_id" name="buku_id" required>
                                    <option value="" disabled selected>Pilih Buku</option>
                                    <?php while ($book = mysqli_fetch_assoc($result_books)) : ?>
                                        <option value="<?= $book['id'] ?>"><?= $book['judul'] ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="tgl_pinjam" class="form-label">Tanggal Pinjam</label>
                                <input type="text" class="form-control" id="tgl_pinjam" name="tgl_pinjam" value="<?= date('Y-m-d') ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label for="batas_pinjam" class="form-label">Batas Pinjam</label>
                                <input type="text" class="form-control" id="batas_pinjam" name="batas_pinjam" value="<?= date('Y-m-d', strtotime('+7 days')) ?>" readonly>
                            </div>
                            <button type="submit" name="tambah" class="btn btn-success">Simpan</button>
                            <a href="peminjaman.php" class="btn btn-danger">Batal</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoIExlF5nqU93SKmZo7lr1luIs03M9WliH/2ZA/h2Bx0q2F" crossorigin="anonymous"></script>
</body>

</html>