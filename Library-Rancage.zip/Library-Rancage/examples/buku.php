<?php
include "session.php";
include "../koneksi.php";

// Inisialisasi variabel pencarian
$search = "";
if (isset($_GET['search'])) {
  $search = $_GET['search'];
  // Query untuk mencari buku berdasarkan pencarian user dan menampilkan kategori buku
  $query = "SELECT buku.*, GROUP_CONCAT(kategoribuku.nama_kategori SEPARATOR ', ') AS kategori
            FROM buku
            LEFT JOIN kategoribuku_relasi ON buku.id = kategoribuku_relasi.buku_id
            LEFT JOIN kategoribuku ON kategoribuku_relasi.kategori_id = kategoribuku.id
            WHERE buku.id LIKE '%$search%' OR buku.judul LIKE '%$search%' OR buku.penulis LIKE '%$search%' 
              OR buku.penerbit LIKE '%$search%' OR buku.tahun_terbit LIKE '%$search%'
            GROUP BY buku.id";
} else {
  // Query untuk menampilkan semua buku dengan kategori
  $query = "SELECT buku.*, GROUP_CONCAT(kategoribuku.nama_kategori SEPARATOR ', ') AS kategori
            FROM buku
            LEFT JOIN kategoribuku_relasi ON buku.id = kategoribuku_relasi.buku_id
            LEFT JOIN kategoribuku ON kategoribuku_relasi.kategori_id = kategoribuku.id
            GROUP BY buku.id";
}

$result = mysqli_query($koneksi, $query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    PERPUSTAKAAN RANCAGE
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <link href="../assets/demo/demo.css" rel="stylesheet" />
  <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
</head>

<body class="">
  <div class="wrapper">
    <div class="sidebar" data-color="white" data-active-color="info">
      <div class="logo">
        <a href="" class="simple-text logo-mini">
          <div class="logo-image-mini">
            <i class="fa-solid fa-book-open-reader text-primary"></i>
          </div>
        </a>
        <a href="" class="h6 logo-normal text-primary" style="text-decoration: none;">
          DASHBOARD ADMIN PERPUSTAKAAN RANCAGE

        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li>
            <a href="./dashboard.php">
              <i class="fa-solid fa-house-chimney"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="active">
            <a href="./buku.php">
              <i class="fa-solid fa-book"></i>
              <p>Buku</p>
            </a>
          </li>
          <li>
            <a href="./peminjaman.php">
              <i class="fa-solid fa-book-bookmark"></i>
              <p>Daftar Peminjaman</p>
            </a>
          </li>
          <li>
            <a href="./kunjungan.php">
              <i class="fa-solid fa-person-walking-arrow-right"></i>
              <p>Daftar Kunjungan</p>
            </a>
          </li>
          <li>
            <a href="./ulasan.php">
              <i class="fa-solid fa-comments"></i>
              <p>Ulasan Buku</p>
            </a>
          </li>
          <li>
            <a href="./user.php">
              <i class="fa-solid fa-user"></i>
              <p>User List</p>
            </a>
          </li>
          <li>
            <a href="./kategori.php">
              <i class="fa-solid fa-list"></i>
              <p>Kategori</p>
            </a>
          </li>
          <hr>
          <li>
            <a href="./logout.php" class="text-danger" onclick="return confirm('Apakah Anda yakin ingin Logout?')">
              <i class="fa-solid fa-arrow-right-from-bracket text-danger"></i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <!-- Sidebar Akhir -->

    <!-- Main Panel -->
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="javascript:;">Buku</a>
          </div>
          <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <form action="" method="GET">
              <div class="input-group no-border">
                <!-- Tombol X untuk reset pencarian -->
                <?php if (!empty($search)) { ?>
                  <div class="input-group-prepend">
                    <a href="buku.php" class="input-group-text">
                      <i class="nc-icon nc-simple-remove"></i>
                    </a>
                  </div>
                <?php } ?>
                <!-- Input pencarian -->
                <input type="text" name="search" value="<?php echo $search; ?>" class="form-control" placeholder="Cari Buku">
                <div class="input-group-append">
                  <button type="submit" class="input-group-text">
                    <i class="nc-icon nc-zoom-split"></i>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->

      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title">DAFTAR BUKU</h4>
              </div>
              <div class="card-body">
                <a href="add_buku.php"><button class="btn btn-info" title="Tambah Buku"><i class='fa-solid fa-add'></i> Tambah Buku</button></a>
                <div class="table-responsive">
                  <table class="table">
                    <thead>
                      <th>ID BUKU</th>
                      <th>SAMPUL</th>
                      <th>JUDUL BUKU</th>
                      <th>PENULIS</th>
                      <th>PENERBIT</th>
                      <th>TAHUN TERBIT</th>
                      <th>KATEGORI</th>
                      <th>AKSI</th>
                    </thead>
                    <tbody>
                      <?php
                      if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                          echo "<tr>";
                          echo "<td>" . $row['id'] . "</td>";
                          echo "<td><img src='../cover_buku/" . $row['sampul'] . "' alt='Sampul Buku' width='100'></td>"; // Update bagian ini
                          echo "<td>" . $row['judul'] . "</td>";
                          echo "<td>" . $row['penulis'] . "</td>";
                          echo "<td>" . $row['penerbit'] . "</td>";
                          echo "<td>" . $row['tahun_terbit'] . "</td>";
                          echo "<td>" . $row['kategori'] . "</td>";
                          echo "<td>";
                          echo "<a href='edit_buku.php?id=" . $row['id'] . "' class='btn btn-primary btn-sm mb-1' title='Edit Buku'><i class='fa-solid fa-eye'></i></a> ";
                          echo "</td>";
                          echo "</tr>";
                        }
                      } else {
                        echo "<tr><td colspan='7'>Tidak ada data yang ditemukan</td></tr>";  // Kolom total disesuaikan menjadi 7
                      }
                      ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
    <!-- Penutup Main Panel -->
  </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/tooltip.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!-- Chart JS -->
  <script src="../assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>
  <!-- Paper Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
</body>

</html>