<?php
include '../koneksi.php';
require 'vendor/autoload.php'; // Pastikan Dompdf terpasang dengan Composer

use Dompdf\Dompdf;

// Ambil data user dari database berdasarkan ID
$id = $_GET['id'];
$result = mysqli_query($koneksi, "SELECT * FROM user WHERE id = '$id'");
$row = mysqli_fetch_assoc($result);

if (!$row) {
    die("Data user tidak ditemukan.");
}

// Validasi data foto
$image_path = '../foto_user/' . $row['foto'];
if (empty($row['foto']) || !file_exists($image_path)) {
    $image_path = '../foto_user/default.jpg'; // Gambar default jika foto tidak ada
}

// Konversi foto ke base64
$image_data = base64_encode(file_get_contents($image_path));
$image_src = 'data:image/jpeg;base64,' . $image_data;

// Generate QR Code
require_once('../assets/phpqrcode/qrlib.php');
$qr_dir = "../qrcodes/";
$kode = "Perpustakaan/" . $row['id'] . "/" . $row['namalengkap'];
$qr_file = $qr_dir . "qrcode_" . $row['namalengkap'] . ".png";

if (!file_exists($qr_file)) {
    if (!is_dir($qr_dir)) {
        mkdir($qr_dir, 0777, true);
    }
    QRcode::png($kode, $qr_file, "M", 4, 2);
}

// Validasi QR Code
if (!file_exists($qr_file)) {
    die("QR Code tidak berhasil dibuat.");
}

// Konversi QR Code ke base64
$qr_data = base64_encode(file_get_contents($qr_file));
$qr_src = 'data:image/png;base64,' . $qr_data;

// Inisialisasi Dompdf
$dompdf = new Dompdf();

// Template HTML untuk kartu anggota
$html = '
<!DOCTYPE html>
<html>
<head>
    <style>
        @page {
            margin: 0;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .page {
            width: 210mm;
            height: 297mm;
            padding: 10mm;
            display: flex;
            justify-content: center;
        }

        .card {
            width: 85.6mm; /* Ukuran Kartu Anggota (Lebar) */
            height: 53.98mm; /* Ukuran Kartu Anggota (Tinggi) */
            border: 1px solid #000;
            padding: 0px;
            box-sizing: border-box;
            display: flex; /* Gunakan flexbox agar foto dan detail sejajar dalam satu baris */
            align-items: center; /* Vertikal sejajar */
            border-radius :20px;
        }

        .header {
            text-align: center;
            font-weight: bold;
            font-size: 12px;
            width: 100%;
           
        }

        .content {
            display: flex; /* Pastikan foto dan teks sejajar di satu baris */
            align-items: center; /* Menjaga agar foto dan teks sejajar secara vertikal */
            width: 100%;
        }

        .details {
            flex: 1; /* Membuat teks mengambil sisa ruang setelah foto */
            font-size: 10px;
            margin-right: 5mm;
            margin-left: 20mm;
        }

        .details p {
            margin: 2px 0;
        }

        .photo {
            margin-right: 5mm;
            margin-top : -20mm;
            margin-left : 10px;
        }

        .photo img {
            width: 15mm; /* Lebar foto yang lebih kecil */
            height: 20mm; /* Tinggi foto yang lebih kecil */
            object-fit: cover;
        }

        .qrcode img {
            width: 10mm; /* Lebar QR Code */
            height: 10mm; /* Tinggi QR Code */
            margin-left: 270px;
            margin-top : -15px;
        }
    </style>
</head>
<body>
    <div class="page">
        <div class="card">
            <div style="display: flex; align-items: center; margin-bottom: 20px; width: 100%; background-color: #34e8eb;  border-radius: 15 15 0 0;">
                <div style="margin-left: 20px; flex-grow: 1;">
                    <span style="font-size: 12px; font-weight: bold; color: black;">PERPUSTAKAAN RANCAGE</span><br>
                    <small style="font-size: 9px; color: black;">Jl. Pendidikan No. 123, Kota Buku</small>
                    <hr style="margin-right: 10px;">
                </div>
            </div>
            <div class="header">KARTU ANGGOTA</div>
            <div class="content">
                <div class="details">
                    <p><strong>ID :</strong> ' . htmlspecialchars($row['id']) . '</p>
                    <p><strong>Nama :</strong> ' . htmlspecialchars($row['namalengkap']) . '</p>
                    <p><strong>Email :</strong> ' . htmlspecialchars($row['email']) . '</p>
                    <p><strong>Alamat :</strong> ' . htmlspecialchars($row['alamat']) . '</p>
                </div>
                <div class="photo">
                    <img src="' . $image_src . '" alt="Foto User">
                </div>
                <div class="qrcode">
                    <img src="' . $qr_src . '" alt="QR Code">
                </div>
            </div>
        </div>
    </div>
</body>
</html>
';

// Muat konten HTML ke Dompdf
$dompdf->loadHtml($html);

// Set ukuran halaman ke A4
$dompdf->setPaper('A4', 'portrait');

// Render PDF
$dompdf->render();

// Output file PDF ke browser
$dompdf->stream("Kartu_Anggota_{$row['id']}.pdf", ["Attachment" => false]);
