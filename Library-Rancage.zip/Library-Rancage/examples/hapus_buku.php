<?php
include '../koneksi.php';

// Cek apakah ada ID buku yang dikirim melalui URL
if (isset($_GET['id'])) {
    $id_buku = $_GET['id'];

    // Query untuk menghapus data buku berdasarkan ID
    $query = "DELETE FROM buku WHERE id = ?";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, "i", $id_buku);

    // Eksekusi query dan cek apakah berhasil
    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Buku berhasil dihapus!'); window.location='../examples/buku.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus buku!'); window.location='../examples/buku.php';</script>";
    }
} else {
    echo "<script>alert('ID buku tidak ditemukan!'); window.location='../examples/buku.php';</script>";
}
