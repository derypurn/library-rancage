<?php
include "../koneksi.php";
include "session.php"; // Validasi session untuk admin


// Ambil ID dari URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];
} else {
    die("ID pengguna tidak ditemukan.");
}

// Ambil data user berdasarkan ID
$query_user = "SELECT * FROM user WHERE id = ?";
$stmt = $koneksi->prepare($query_user);
$stmt->bind_param("i", $id);
$stmt->execute();
$result_user = $stmt->get_result();

if ($result_user->num_rows > 0) {
    $userData = $result_user->fetch_assoc();
} else {
    $_SESSION['message'] = "Pengguna tidak ditemukan.";
    $_SESSION['message_type'] = "danger";
    header("Location: user.php");
    exit();
}

// Jika form dikirimkan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $namalengkap = $_POST['namalengkap'];
    $alamat = $_POST['alamat'];
    $level = $_POST['level'];
    $foto = $_FILES['foto'];

    // Penanganan file foto
    $foto_name = $userData['foto']; // Foto default adalah foto lama
    if ($foto['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($foto['name'], PATHINFO_EXTENSION);
        $foto_name = uniqid('foto_') . '.' . $ext;

        // Pindahkan file baru
        move_uploaded_file($foto['tmp_name'], "../foto_user/$foto_name");

        // Hapus foto lama jika bukan default
        if ($userData['foto'] && $userData['foto'] !== 'default.jpg' && file_exists("../foto_user/" . $userData['foto'])) {
            unlink("../foto_user/" . $userData['foto']);
        }
    }

    // Update data user di database
    $query_update = "UPDATE user SET username = ?, namalengkap = ?, alamat = ?, level = ?, foto = ? WHERE id = ?";
    $stmt = $koneksi->prepare($query_update);
    $stmt->bind_param("sssssi", $username, $namalengkap, $alamat, $level, $foto_name, $id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "<script>alert('Data berhasil diubah.'); window.location.href = 'user.php';</script>";
    } else {
        echo "<script>alert('Data gagal diubah.'); window.location.href = 'user.php';</script>";
    }

    header("Location: user.php");
    exit();
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        PERPUSTAKAAN RANCAGE
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="../assets/demo/demo.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
    <script>
        function toggleEdit() {
            var inputs = document.querySelectorAll('.form-control');
            var editButton = document.getElementById('editButton');
            var saveButton = document.getElementById('saveButton');
            var fotoInput = document.getElementById('foto');
            var isReadonly = inputs[0].readOnly;

            inputs.forEach(function(input, index) {
                if (index !== 4) { // Skip level (indeks 4)
                    input.readOnly = !isReadonly; // Ubah status readonly
                }
            });

            fotoInput.disabled = !isReadonly;

            if (isReadonly) {
                editButton.innerText = 'X';
                saveButton.disabled = false; // Aktifkan tombol simpan
            } else {
                editButton.innerText = 'EDIT';
                saveButton.disabled = true; // Nonaktifkan tombol simpan
            }
        }
    </script>
</head>

<body class="">
    <div class="wrapper">
        <div class="sidebar" data-color="white" data-active-color="info">
            <div class="logo">
                <a href="" class="simple-text logo-mini">
                    <div class="logo-image-mini">
                        <i class="fa-solid fa-book-open-reader text-primary"></i>
                    </div>
                </a>
                <a href="" class="h6 logo-normal text-primary" style="text-decoration: none;">
                    DASHBOARD ADMIN PERPUSTAKAAN RANCAGE
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li>
                        <a href="./dashboard.php">
                            <i class="fa-solid fa-house-chimney"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li>
                        <a href="./buku.php">
                            <i class="fa-solid fa-book"></i>
                            <p>Buku</p>
                        </a>
                    </li>
                    <li>
                        <a href="./peminjaman.php">
                            <i class="fa-solid fa-book-bookmark"></i>
                            <p>Daftar Peminjaman</p>
                        </a>
                    </li>
                    <li>
                        <a href="./ulasan.php">
                            <i class="fa-solid fa-comments"></i>
                            <p>Ulasan Buku</p>
                        </a>
                    </li>
                    <li class="active">
                        <a href="./user.php">
                            <i class="fa-solid fa-user"></i>
                            <p>User List</p>
                        </a>
                    </li>
                    <li>
                        <a href="./kategori.php">
                            <i class="fa-solid fa-list"></i>
                            <p>Kategori</p>
                        </a>
                    </li>
                    <hr>
                    <li>
                        <a href="./logout.php" class="text-danger" onclick="return confirm('Apakah Anda yakin ingin Logout?')">
                            <i class="fa-solid fa-arrow-right-from-bracket text-danger"></i>
                            <p>Logout</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                        <a class="navbar-brand" href="javascript:;">List User</a>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                    </button>
                </div>
            </nav>
            <!-- End Navbar -->
            <div class="content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Edit Data User</h4>
                            </div>
                            <div class="card-body">
                                <form action="update_user.php" method="POST" id="userForm" enctype="multipart/form-data">
                                    <div class="form-group text-center">
                                        <!-- Updated image styling for circular display -->
                                        <img style="width: 150px; height: 150px;" src="../foto_user/<?php echo htmlspecialchars($userData['foto'] ?? 'default.jpg'); ?>"
                                            alt="Foto Profil" class="img-thumbnail mb-2 rounded-circle">
                                        <input type="file" class="form-control" id="foto" name="foto" accept="image/*">
                                    </div>
                                    <div class="form-group">
                                        <label for="username">Username:</label>
                                        <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($userData['username']); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="namalengkap">Nama Lengkap:</label>
                                        <input type="text" class="form-control" id="namalengkap" name="namalengkap" value="<?php echo htmlspecialchars($userData['namalengkap']); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email:</label>
                                        <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($userData['email']); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="alamat">Alamat:</label>
                                        <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo htmlspecialchars($userData['alamat']); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="level">Level:</label>
                                        <select class="form-control" id="level" name="level" required>
                                            <option value="admin" <?php echo $userData['level'] == 'admin' ? 'selected' : ''; ?>>Admin</option>
                                            <option value="petugas" <?php echo $userData['level'] == 'petugas' ? 'selected' : ''; ?>>Petugas</option>
                                            <option value="peminjam" <?php echo $userData['level'] == 'peminjam' ? 'selected' : ''; ?>>Peminjam</option>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn btn-primary mt-3" id="saveButton">Simpan</button>
                                </form>
                                <a href="user.php"><i class="fa-solid fa-arrow-left ml-2 text-warning" style="font-size: 35px;"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- Core JS Files -->
    <script src="../assets/js/core/jquery.min.js"></script>
    <script src="../assets/js/tooltip.js"></script>
    <script src="../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap.min.js"></script>
</body>

</html>