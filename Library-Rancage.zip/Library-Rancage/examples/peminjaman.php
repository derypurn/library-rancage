<?php
include "../koneksi.php";
include "session.php";

// Menangani parameter pengurutan dari URL
$order_by = isset($_GET['order_by']) ? $_GET['order_by'] : 'tgl_pinjam'; // default ke tgl_pinjam
$sort_order = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'DESC'; // default ke DESC
$search = isset($_GET['search']) ? mysqli_real_escape_string($koneksi, $_GET['search']) : ''; // Cegah SQL Injection

// Query untuk menampilkan data peminjaman dengan pencarian dan pengurutan
$query_peminjaman = "
    SELECT peminjaman.id, user.namalengkap, buku.judul, peminjaman.tgl_pinjam, peminjaman.tgl_kembali, peminjaman.batas_pinjam, peminjaman.status
    FROM peminjaman
    JOIN user ON peminjaman.user_id = user.id
    JOIN buku ON peminjaman.buku_id = buku.id
    WHERE user.namalengkap LIKE '%$search%' OR buku.judul LIKE '%$search%'
    ORDER BY $order_by $sort_order";
$result_peminjaman = mysqli_query($koneksi, $query_peminjaman);
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    PERPUSTAKAAN RANCAGE
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <link href="../assets/demo/demo.css" rel="stylesheet" />
  <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="info">
      <div class="logo">
        <a href="" class="simple-text logo-mini">
          <div class="logo-image-mini">
            <i class="fa-solid fa-book-open-reader text-primary"></i>
          </div>
        </a>
        <a href="" class="h6 logo-normal text-primary" style="text-decoration: none;">
          DASHBOARD ADMIN PERPUSTAKAAN RANCAGE

        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li>
            <a href="./dashboard.php">
              <i class="fa-solid fa-house-chimney"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <li>
            <a href="./buku.php">
              <i class="fa-solid fa-book"></i>
              <p>Buku</p>
            </a>
          </li>
          <li class="active">
            <a href="./peminjaman.php">
              <i class="fa-solid fa-book-bookmark"></i>
              <p>Daftar Peminjaman</p>
            </a>
          </li>
          <li>
            <a href="./kunjungan.php">
              <i class="fa-solid fa-person-walking-arrow-right"></i>
              <p>Daftar Kunjungan</p>
            </a>
          </li>
          <li>
          <li>
            <a href="./ulasan.php">
              <i class="fa-solid fa-comments"></i>
              <p>Ulasan Buku</p>
            </a>
          </li>
          <li>
            <a href="./user.php">
              <i class="fa-solid fa-user"></i>
              <p>User List</p>
            </a>
          </li>
          <li>
            <a href="./kategori.php">
              <i class="fa-solid fa-list"></i>
              <p>Kategori</p>
            </a>
          </li>
          <hr>
          <li>
            <a href="./logout.php" class="text-danger" onclick="return confirm('Apakah Anda yakin ingin Logout?')">
              <i class="fa-solid fa-arrow-right-from-bracket text-danger"></i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="javascript:;">List Peminjaman</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <form method="GET">
              <div class="input-group no-border">
                <input name="search" type="text" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>" class="form-control" placeholder="Cari Peminjaman">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <i class="nc-icon nc-zoom-split" type="submit"></i>
                  </div>
                </div>
              </div>
            </form>
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link btn-magnify" href="javascript:;">
                  <i class="nc-icon nc-layout-11"></i>
                  <p>
                    <span class="d-lg-none d-md-block">Stats</span>
                  </p>
                </a>
              </li>
              <li class="nav-item btn-rotate dropdown">
                <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="nc-icon nc-bell-55"></i>
                  <p>
                    <span class="d-lg-none d-md-block">Some Actions</span>
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="#">Action</a>
                  <a class="dropdown-item" href="#">Another action</a>
                  <a class="dropdown-item" href="#">Something else here</a>
                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link btn-rotate" href="javascript:;">
                  <i class="nc-icon nc-settings-gear-65"></i>
                  <p>
                    <span class="d-lg-none d-md-block">Account</span>
                  </p>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title">DAFTAR PEMINJAMAN</h4>
              </div>
              <div class="card-body">
                <a href="add_peminjaman.php" class="btn btn-primary"><i class='fa-solid fa-add'></i> Tambah Peminjaman</a>
                <a href="cetak_peminjaman.php" class="btn btn-info"><i class='fa-solid fa-print'></i> Cetak Semua Laporan</a>
                <div class="table-responsive">
                  <table class="table">
                    <thead>
                      <th>NO</th>
                      <th>USERNAME</th>
                      <th>JUDUL BUKU</th>
                      <th>
                        TANGGAL PINJAM
                        <a href="?order_by=tgl_pinjam&sort_order=<?php echo ($sort_order == 'ASC') ? 'DESC' : 'ASC'; ?>">
                          ●
                        </a>
                      </th>
                      <th>BATAS PINJAM</th>
                      <th>
                        TANGGAL KEMBALI
                        <a href="?order_by=tgl_kembali&sort_order=<?php echo ($sort_order == 'ASC') ? 'DESC' : 'ASC'; ?>">
                          ●
                        </a>
                      </th>
                      <th>STATUS</th>
                      <th>DENDA</th>
                      <th>AKSI</th>
                    </thead>
                    <tbody>
                      <?php
                      if (mysqli_num_rows($result_peminjaman) > 0) {
                        $no = 1;
                        while ($row = mysqli_fetch_assoc($result_peminjaman)) {
                          if (!empty($row['batas_pinjam'])) {
                            $batasPinjam = new DateTime($row['batas_pinjam']);
                            $tanggalHariIni = new DateTime();

                            if ($tanggalHariIni > $batasPinjam) {
                              $selisihHari = $tanggalHariIni->diff($batasPinjam)->days;
                              $denda = $selisihHari * 1000;
                            } else {
                              $denda = 0;
                            }
                          } else {
                            $denda = 0;
                          }

                          echo "<tr>";
                          echo "<td>" . $no++ . "</td>";
                          echo "<td>" . htmlspecialchars($row['namalengkap'] ?? '') . "</td>";
                          echo "<td>" . htmlspecialchars($row['judul'] ?? '') . "</td>";
                          echo "<td>" . htmlspecialchars($row['tgl_pinjam'] ?? '') . "</td>";
                          echo "<td>" . htmlspecialchars($row['batas_pinjam'] ?? '') . "</td>";
                          echo "<td>" . htmlspecialchars($row['tgl_kembali'] ?? '-') . "</td>";
                          echo "<td>";
                      ?>
                          <form method="POST" action="update_status.php">
                            <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id'] ?? ''); ?>">
                            <select name="status" class="form-control" onchange="this.form.submit()">
                              <option value="dipinjam" <?php if ($row['status'] == 'dipinjam') echo 'selected'; ?>>Dipinjam</option>
                              <option value="dikembalikan" <?php if ($row['status'] == 'dikembalikan') echo 'selected'; ?>>Dikembalikan</option>
                            </select>
                          </form>
                      <?php
                          echo "</td>";
                          echo "<td>Rp" . number_format($denda, 0, ',', '.') . "</td>";
                          echo "<td>";
                          echo "<a href='cetak_laporan.php?id=" . htmlspecialchars($row['id'] ?? '') . "' class='btn btn-primary' title='cetak laporan'><i class='fa-solid fa-print'></i></a>";
                          echo "</td>";
                          echo "</tr>";
                        }
                      } else {
                        echo "<tr><td colspan='9'>Tidak ada data peminjaman yang ditemukan</td></tr>";
                      }
                      ?>
                    </tbody>
                  </table>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>

      <footer class="footer footer-black  footer-white ">
        <div class="container-fluid">
          <div class="row">
            <nav class="footer-nav">
              <ul>
                <li><a href="https://www.creative-tim.com" target="_blank">Creative Tim</a></li>
                <li><a href="https://www.creative-tim.com/blog" target="_blank">Blog</a></li>
                <li><a href="https://www.creative-tim.com/license" target="_blank">Licenses</a></li>
              </ul>
            </nav>
            <div class="credits ml-auto">
              <span class="copyright">
                © <script>
                  document.write(new Date().getFullYear())
                </script>, made with <i class="fa fa-heart heart"></i> by Creative Tim
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!--   Core JS Files   -->

  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/tooltip.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="../assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script><!-- Paper Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
</body>

</html>