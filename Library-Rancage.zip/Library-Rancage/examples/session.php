<?php
session_start();
if (!isset($_SESSION['email'])) {
    echo "<script>alert('Anda tidak memiliki akses kesini!'); window.location.href = '../index.php';</script>";
}

if ($_SESSION['level'] !== 'admin') { // Ganti 'admin' sesuai level yang diizinkan
    echo "<script>alert('Anda tidak memiliki akses kesini!'); window.location.href = '../index.php';</script>";
}
