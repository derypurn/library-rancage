<?php
include '../koneksi.php';

if (isset($_GET['id'])) {
    $id_buku = $_GET['id'];

    $query = "DELETE FROM kategoribuku WHERE id = ?";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, "i", $id_buku);
    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Kategori berhasil dihapus!'); window.location='../examples/kategori.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus Kategori!'); window.location='../examples/kategori.php';</script>";
    }
} else {
    echo "<script>alert('ID kategori tidak ditemukan!'); window.location='../examples/kategori.php';</script>";
}
