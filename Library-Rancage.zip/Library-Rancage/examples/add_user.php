<?php
include '../koneksi.php';
include 'session.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../assets/phpmailer/src/Exception.php';
require '../assets/phpmailer/src/PHPMailer.php';
require '../assets/phpmailer/src/SMTP.php';

if (isset($_POST['tambah'])) {
    $id = $koneksi->real_escape_string($_POST['id']);
    $username = $koneksi->real_escape_string($_POST['username']);
    $email = $koneksi->real_escape_string($_POST['email']);
    $namalengkap = $koneksi->real_escape_string($_POST['namalengkap']);
    $alamat = $koneksi->real_escape_string($_POST['alamat']);
    $level = $koneksi->real_escape_string($_POST['level']);

    // Menyimpan password asli (sebelum di-hash)
    $password_asli = $_POST['password'];

    // Menggunakan md5 untuk hashing password untuk penyimpanan di database
    $password = md5($password_asli);

    // Cek apakah username atau email sudah terdaftar
    $query = "SELECT * FROM user WHERE username='$username' OR email='$email'";
    $result = $koneksi->query($query);

    if ($result->num_rows == 0) {
        // Menyusun query INSERT dengan urutan kolom yang benar
        $query = "INSERT INTO user (id, username, password, email, namalengkap, alamat, level) 
              VALUES ('$id', '$username', '$password', '$email', '$namalengkap', '$alamat', '$level')";

        if ($koneksi->query($query)) {
            // Jika berhasil registrasi
            $success = "Registrasi berhasil! Silakan kembali ke form login.";

            // Kirim email pendaftaran menggunakan PHPMailer
            try {
                // Inisialisasi PHPMailer
                $mail = new PHPMailer(true);

                //Server settings
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'derypurn07@gmail.com'; // Email pengirim
                $mail->Password = 'nqpk lsdf ytfn qdxt'; // Sandi aplikasi
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                // Penerima
                $mail->setFrom('derypurn07@gmail.com', 'Library Rancage');
                $mail->addAddress($email); // Email penerima diambil dari form registrasi

                // Konten email
                $mail->isHTML(true);
                $mail->Subject = 'Pendaftaran akun di Library Rancage Sukses!';
                $mail->Body    = "Selamat datang, <strong>$namalengkap</strong>, di Library Rancage.<br><br>
                          ID pengguna Anda: <strong>$id</strong><br>
                          Password Anda: <strong>$password_asli</strong><br><br>
                          Terima kasih telah mendaftar.";

                // Kirim email
                $mail->send();
            } catch (Exception $e) {
                $error = "Terjadi kesalahan saat mengirim email: {$mail->ErrorInfo}";
            }
        } else {
            // Jika ada kesalahan pada query
            $error = "Terjadi kesalahan saat registrasi: " . $koneksi->error;
        }
    } else {
        // Jika username atau email sudah terdaftar
        $error = "Username atau email sudah terdaftar!";
    }
}

$sql = "SELECT MAX(id) AS last_id FROM user";
$result = $koneksi->query($sql);
$row = $result->fetch_assoc();
$last_id = $row['last_id'] + 1;

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        PERPUSTAKAAN RANCAGE
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="../assets/demo/demo.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4>Tambah User</h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="mb-3">
                                <label for="id_buku" class="form-label">ID User</label>
                                <input type="text" class="form-control" id="id" name="id" value="<?= $last_id ?>" required readonly>
                            </div>
                            <div class="mb-3">
                                <label for="judul" class="form-label">username</label>
                                <input type="text" class="form-control" id="username" name="username" placeholder="Masukkan Username" required>
                            </div>
                            <div class="mb-3">
                                <label for="judul" class="form-label">Nama Lengkap</label>
                                <input type="text" class="form-control" id="namalengkap" name="namalengkap" placeholder="Masukkan Nama Lengkap" required>
                            </div>
                            <div class="mb-3">
                                <label for="judul" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan Email" required>
                            </div>
                            <div class="mb-3">
                                <label for="judul" class="form-label">Password</label>
                                <input type="Password" class="form-control" id="password" name="password" placeholder="Masukkan Password" required>
                            </div>
                            <div class="mb-3">
                                <label for="judul" class="form-label">Alamat</label>
                                <input type="text" class="form-control" id="alamat" name="alamat" placeholder="Masukkan Alamat" required>
                            </div>
                            <div class="mb-3">
                                <label for="judul" class="form-label">level</label>
                                <select name="level" id="level" class="form-control">
                                    <option value="peminjam">Peminjam</option>
                                    <option value="Petugas">Petugas</option>
                                    <option value="Admin">Admin</option>
                                </select>
                            </div>
                            <button type="submit" name="tambah" class="btn btn-success">Simpan</button>
                            <a href="user.php" class="btn btn-danger">Batal</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoIExlF5nqU93SKmZo7lr1luIs03M9WliH/2ZA/h2Bx0q2F" crossorigin="anonymous"></script>
</body>

</html>