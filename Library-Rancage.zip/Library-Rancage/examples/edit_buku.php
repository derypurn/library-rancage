<?php
include '../koneksi.php';

// Ambil ID buku dari URL
if (isset($_GET['id'])) {
    $id_buku = $_GET['id'];

    // Query untuk mendapatkan data buku beserta kategorinya
    $query = "SELECT * FROM buku WHERE id = ?";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, "i", $id_buku);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    // Jika data ditemukan
    if (mysqli_num_rows($result)) {
        $buku = mysqli_fetch_assoc($result);
    } else {
        echo "Buku tidak ditemukan";
        exit;
    }

    // Ambil kategori yang terkait dengan buku dari tabel kategoribuku_relasi
    $queryKategoriRelasi = "
        SELECT k.id, k.nama_kategori 
        FROM kategoribuku k
        JOIN kategoribuku_relasi kr ON kr.kategori_id = k.id
        WHERE kr.buku_id = ?";
    $stmtKategoriRelasi = mysqli_prepare($koneksi, $queryKategoriRelasi);
    mysqli_stmt_bind_param($stmtKategoriRelasi, "i", $id_buku);
    mysqli_stmt_execute($stmtKategoriRelasi);
    $resultKategoriRelasi = mysqli_stmt_get_result($stmtKategoriRelasi);
}

// Proses update data buku jika form disubmit
if (isset($_POST['update'])) {
    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $penerbit = $_POST['penerbit'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $id_kategori = $_POST['kategoribuku']; // Kategori yang dipilih dari form

    // Menangani upload gambar sampul baru
    $sampul_baru = $_FILES['sampul']['name'];
    if ($sampul_baru) {
        // Jika ada gambar baru, upload gambar
        $target_dir = "../cover_buku/";
        $target_file = $target_dir . basename($sampul_baru);
        move_uploaded_file($_FILES["sampul"]["tmp_name"], $target_file);
        $querySampul = ", sampul = '$sampul_baru'"; // Update gambar sampul
    } else {
        // Jika tidak ada gambar baru, gunakan gambar lama
        $querySampul = "";
    }

    // Query untuk mengupdate data buku, termasuk kategori dan gambar sampul
    $update_query = "
        UPDATE buku 
        SET judul = ?, penulis = ?, penerbit = ?, tahun_terbit = ? $querySampul
        WHERE id = ?";
    $stmt = mysqli_prepare($koneksi, $update_query);
    mysqli_stmt_bind_param($stmt, "ssssi", $judul, $penulis, $penerbit, $tahun_terbit, $id_buku);

    if (mysqli_stmt_execute($stmt)) {
        // Update kategori di tabel kategoribuku_relasi
        $deleteRelasiQuery = "DELETE FROM kategoribuku_relasi WHERE buku_id = ?";
        $stmtDeleteRelasi = mysqli_prepare($koneksi, $deleteRelasiQuery);
        mysqli_stmt_bind_param($stmtDeleteRelasi, "i", $id_buku);
        mysqli_stmt_execute($stmtDeleteRelasi);

        $insertRelasiQuery = "INSERT INTO kategoribuku_relasi (buku_id, kategori_id) VALUES (?, ?)";
        $stmtInsertRelasi = mysqli_prepare($koneksi, $insertRelasiQuery);
        mysqli_stmt_bind_param($stmtInsertRelasi, "ii", $id_buku, $id_kategori);
        mysqli_stmt_execute($stmtInsertRelasi);

        echo "<script>alert('Data buku berhasil diperbarui!'); window.location='../examples/buku.php';</script>";
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>PERPUSTAKAAN RANCAGE</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="../assets/demo/demo.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4>Edit Buku</h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="current_sampul" class="form-label">Sampul Buku</label><br>
                                <?php if ($buku['sampul']) : ?>
                                    <img src="../cover_buku/<?php echo $buku['sampul']; ?>" alt="Sampul Buku" width="150px" height="200px"><br><br>
                                <?php else : ?>
                                    <p>Tidak ada sampul.</p>
                                <?php endif; ?>
                                <label for="sampul" class="form-label">Ganti Sampul (Opsional)</label>
                                <input type="file" class="form-control" id="sampul" name="sampul">
                            </div>
                            <div class="mb-3">
                                <label for="judul" class="form-label">Judul Buku</label>
                                <input type="text" class="form-control" id="judul" name="judul" value="<?php echo $buku['judul']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="penulis" class="form-label">Penulis</label>
                                <input type="text" class="form-control" id="penulis" name="penulis" value="<?php echo $buku['penulis']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="penerbit" class="form-label">Penerbit</label>
                                <input type="text" class="form-control" id="penerbit" name="penerbit" value="<?php echo $buku['penerbit']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="tahun_terbit" class="form-label">Tahun Terbit</label>
                                <input type="number" class="form-control" id="tahun_terbit" name="tahun_terbit" value="<?php echo $buku['tahun_terbit']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="kategoribuku" class="form-label">Kategori Buku</label>
                                <select name="kategoribuku" id="kategoribuku" class="form-control" required>
                                    <option value="">Pilih Kategori</option>
                                    <?php while ($rowKategori = mysqli_fetch_assoc($resultKategoriRelasi)) : ?>
                                        <option value="<?= $rowKategori['id']; ?>" <?= ($rowKategori['id'] == $buku['id']) ? 'selected' : ''; ?>>
                                            <?= $rowKategori['nama_kategori']; ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>

                            <!-- Menampilkan gambar sampul yang sudah ada -->

                            <button type="submit" name="update" class="btn btn-success">Update Buku</button>
                            <a href="hapus_buku.php?id=<?php echo $buku['id']; ?>"
                                class="btn btn-danger"
                                title="Hapus Buku"
                                onclick="return confirm('Apakah Anda yakin ingin menghapus buku')">
                                <i class="fa-solid fa-trash"></i>
                            </a>
                            <a href="buku.php" class="btn btn-info">Batal</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoIExlF5nqU93SKmZo7lr1luIs03M9WliH/2ZA/h2Bx0q2F" crossorigin="anonymous"></script>
</body>

</html>