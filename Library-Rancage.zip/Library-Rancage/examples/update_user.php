<?php
include "../koneksi.php";
session_start();

$email = $_SESSION['email'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $namalengkap = $_POST['namalengkap'];
    $alamat = $_POST['alamat'];
    $foto = $_FILES['foto'];

    // Penanganan file foto
    $foto_name = null;
    if ($foto['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($foto['name'], PATHINFO_EXTENSION);
        $foto_name = uniqid('foto_') . '.' . $ext;
        move_uploaded_file($foto['tmp_name'], "../foto_user/$foto_name");

        // Hapus foto lama
        $query_foto = "SELECT foto FROM user WHERE email = ?";
        $stmt = $koneksi->prepare($query_foto);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $old_foto = $result->fetch_assoc()['foto'];
        if ($old_foto && $old_foto !== 'default.jpg' && file_exists("../foto_user/$old_foto")) {
            unlink("../foto_user/$old_foto");
        }
    }

    // Update database
    $query_update = "UPDATE user SET username = ?, namalengkap = ?, alamat = ?" . ($foto_name ? ", foto = ?" : "") . " WHERE email = ?";
    $stmt = $koneksi->prepare($query_update);
    if ($foto_name) {
        $stmt->bind_param("sssss", $username, $namalengkap, $alamat, $foto_name, $email);
    } else {
        $stmt->bind_param("ssss", $username, $namalengkap, $alamat, $email);
    }
    $stmt->execute();

    header("Location: user.php");
    exit();
}
