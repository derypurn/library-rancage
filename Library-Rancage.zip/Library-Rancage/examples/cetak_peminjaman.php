<?php
include "../koneksi.php";
require 'vendor/autoload.php';

use Dompdf\Dompdf;

// Ambil semua data peminjaman
$query = "
    SELECT 
        peminjaman.id, 
        user.username, 
        user.email, 
        user.alamat, 
        buku.judul, 
        buku.penulis, 
        buku.penerbit, 
        buku.tahun_terbit, 
        peminjaman.tgl_pinjam, 
        peminjaman.tgl_kembali, 
        peminjaman.status,
        peminjaman.batas_pinjam  
    FROM peminjaman
    JOIN user ON peminjaman.user_id = user.id
    JOIN buku ON peminjaman.buku_id = buku.id
    ORDER BY peminjaman.tgl_pinjam DESC";

$result = mysqli_query($koneksi, $query);

// Periksa apakah data ditemukan
if (mysqli_num_rows($result) == 0) {
    die("Tidak ada data peminjaman yang ditemukan.");
}

// Inisialisasi Dompdf
$dompdf = new Dompdf();

// Membuat HTML untuk laporan
$html = '
    <div style="display: flex; align-items: center; margin-bottom: 20px;">
        <div style="margin-left: 10px;">
            <span style="font-size: 18px; font-weight: bold; color: #17a2b8;">PERPUSTAKAAN RANCAGE</span><br>
            <small style="font-size: 12px; color: #6c757d;">Jl. Pendidikan No. 123, Kota Buku</small>
        </div>
    </div>

    <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
        <thead>
            <tr style="background-color: #17a2b8; color: white; text-align: center;">
                <th style="padding: 8px; border: 1px solid #ddd; width: 5%;">ID</th>
                <th style="padding: 8px; border: 1px solid #ddd; width: 10%;">Username</th>
                <th style="padding: 8px; border: 1px solid #ddd; width: 15%;">Email</th>
                <th style="padding: 8px; border: 1px solid #ddd; width: 15%;">Alamat</th>
                <th style="padding: 8px; border: 1px solid #ddd; width: 15%;">Judul Buku</th>
                <th style="padding: 8px; border: 1px solid #ddd; width: 10%;">Penulis</th>
                <th style="padding: 8px; border: 1px solid #ddd; width: 10%;">Penerbit</th>
                <th style="padding: 8px; border: 1px solid #ddd; width: 7%;">Tahun</th>
                <th style="padding: 8px; border: 1px solid #ddd; width: 10%;">Tgl Pinjam</th>
                <th style="padding: 8px; border: 1px solid #ddd; width: 10%;">Tgl Kembali</th>
                <th style="padding: 8px; border: 1px solid #ddd; width: 10%;">Status</th>
                <th style="padding: 8px; border: 1px solid #ddd; width: 8%;">Denda</th>
            </tr>
        </thead>
        <tbody>';

// Iterasi setiap baris data
while ($row = mysqli_fetch_assoc($result)) {
    // Hitung denda
    $denda = 0;
    $tgl_pinjam = new DateTime($row['tgl_pinjam']);
    $tgl_kembali = empty($row['tgl_kembali']) ? null : new DateTime($row['tgl_kembali']);
    $batas_pinjam = empty($row['batas_pinjam']) ? null : new DateTime($row['batas_pinjam']);
    $tgl_sekarang = new DateTime();

    if ($batas_pinjam) {
        if ($row['status'] == 'dipinjam' && $tgl_sekarang > $batas_pinjam) {
            $selisih = $tgl_sekarang->diff($batas_pinjam)->days;
            $denda = $selisih * 1000; // Denda Rp2.000 per hari
        } elseif ($row['status'] == 'dikembalikan' && $tgl_kembali > $batas_pinjam) {
            $selisih = $tgl_kembali->diff($batas_pinjam)->days;
            $denda = $selisih * 1000; // Denda Rp2.000 per hari
        }
    }

    // Tambahkan data ke tabel
    $html .= '<tr style="background-color: #e9f7fc; text-align: center;">
                <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['id']) . '</td>
                <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['username']) . '</td>
                <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['email']) . '</td>
                <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['alamat']) . '</td>
                <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['judul']) . '</td>
                <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['penulis']) . '</td>
                <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['penerbit']) . '</td>
                <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['tahun_terbit']) . '</td>
                <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['tgl_pinjam']) . '</td>
                <td style="padding: 8px; border: 1px solid #ddd;">' . (!empty($row['tgl_kembali']) ? htmlspecialchars($row['tgl_kembali']) : '-') . '</td>
                <td style="padding: 8px; border: 1px solid #ddd;">' . ucfirst(htmlspecialchars($row['status'])) . '</td>
                <td style="padding: 8px; border: 1px solid #ddd;">Rp.' . number_format($denda, 0, ',', '.') . '</td>
              </tr>';
}

$html .= '</tbody></table>';

// Load HTML ke Dompdf
$dompdf->loadHtml($html);

// Set ukuran dan orientasi kertas
$dompdf->setPaper('A4', 'landscape');

// Render PDF
$dompdf->render();

// Output ke browser
header("Content-Type: application/pdf");
$dompdf->stream('laporan_peminjaman.pdf', array('Attachment' => 0));
