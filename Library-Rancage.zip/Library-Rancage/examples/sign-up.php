<?php
session_start();
require "../koneksi.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../assets/phpmailer/src/Exception.php';
require '../assets/phpmailer/src/PHPMailer.php';
require '../assets/phpmailer/src/SMTP.php';

if (isset($_POST['register'])) {
  $id = $koneksi->real_escape_string($_POST['id']);
  $username = $koneksi->real_escape_string($_POST['username']);
  $email = $koneksi->real_escape_string($_POST['email']);
  $namalengkap = $koneksi->real_escape_string($_POST['namalengkap']);
  $alamat = $koneksi->real_escape_string($_POST['alamat']);
  $level = $koneksi->real_escape_string($_POST['level']);

  // Menyimpan password asli (sebelum di-hash)
  $password_asli = $_POST['password'];

  // Menggunakan md5 untuk hashing password untuk penyimpanan di database
  $password = md5($password_asli);

  // Cek apakah username atau email sudah terdaftar
  $query = "SELECT * FROM user WHERE username='$username' OR email='$email'";
  $result = $koneksi->query($query);

  if ($result->num_rows == 0) {
    // Menyusun query INSERT dengan urutan kolom yang benar
    $query = "INSERT INTO user (id, username, password, email, namalengkap, alamat, level) 
              VALUES ('$id', '$username', '$password', '$email', '$namalengkap', '$alamat', '$level')";

    if ($koneksi->query($query)) {
      // Jika berhasil registrasi
      $success = "Registrasi berhasil! Silakan kembali ke form login.";

      // Kirim email pendaftaran menggunakan PHPMailer
      try {
        // Inisialisasi PHPMailer
        $mail = new PHPMailer(true);

        //Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'derypurn07@gmail.com'; // Email pengirim
        $mail->Password = 'nqpk lsdf ytfn qdxt'; // Sandi aplikasi
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Penerima
        $mail->setFrom('derypurn07@gmail.com', 'Library Rancage');
        $mail->addAddress($email); // Email penerima diambil dari form registrasi

        // Konten email
        $mail->isHTML(true);
        $mail->Subject = 'Pendaftaran akun di Library Rancage Sukses!';
        $mail->Body    = "Selamat datang, <strong>$namalengkap</strong>, di Library Rancage.<br><br>
                          ID pengguna Anda: <strong>$id</strong><br>
                          Password Anda: <strong>$password_asli</strong><br><br>
                          Terima kasih telah mendaftar.";

        // Kirim email
        $mail->send();
      } catch (Exception $e) {
        $error = "Terjadi kesalahan saat mengirim email: {$mail->ErrorInfo}";
      }
    } else {
      // Jika ada kesalahan pada query
      $error = "Terjadi kesalahan saat registrasi: " . $koneksi->error;
    }
  } else {
    // Jika username atau email sudah terdaftar
    $error = "Username atau email sudah terdaftar!";
  }
}

$sql = "SELECT MAX(id) AS last_id FROM user";
$result = $koneksi->query($sql);
$row = $result->fetch_assoc();
$last_id = $row['last_id'] + 1;
?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    PERPUSTAKAAN RANCAGE
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <link href="../assets/demo/demo.css" rel="stylesheet" />
  <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
</head>

<body class="">
  <nav class="navbar navbar-expand-lg position-absolute top-0 z-index-3 w-100 shadow-none my-3 navbar-transparent mt-4">
    <div class="container">
      <a class="navbar-brand font-weight-bolder ms-lg-0 ms-3 text-white" href="">
        LIBRARY RANCAGE
      </a>
      <button class="navbar-toggler shadow-none ms-2" type="button" data-bs-toggle="collapse" data-bs-target="#navigation" aria-controls="navigation" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon mt-2">
          <span class="navbar-toggler-bar bar1"></span>
          <span class="navbar-toggler-bar bar2"></span>
          <span class="navbar-toggler-bar bar3"></span>
        </span>
      </button>
      <div class="collapse navbar-collapse" id="navigation">
        <ul class="navbar-nav mx-auto">
          <li class="nav-item"><a class="nav-link d-flex align-items-center me-2 active" aria-current="page" href="../examples/dashboard.php"><i class="fa fa-chart-pie opacity-6 me-1"></i>Dashboard</a></li>
          <li class="nav-item"><a class="nav-link me-2" href="../examples/user.php"><i class="fa fa-user opacity-6 me-1"></i>Profile</a></li>
          <li class="nav-item"><a class="nav-link me-2" href="../examples/sign-up.php"><i class="fas fa-user-circle opacity-6 me-1"></i>Daftar</a></li>
          <li class="nav-item"><a class="nav-link me-2" href="../index.php"><i class="fas fa-key opacity-6 me-1"></i>Login</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <main class="main-content mt-0">
    <div class="page-header align-items-start min-vh-50 pt-5 pb-11 m-3 border-radius-lg" style="background-image: url('https://raw.githubusercontent.com/creativetimofficial/public-assets/master/argon-dashboard-pro/assets/img/signup-cover.jpg'); background-position: top;">
      <span class="mask bg-gradient-dark opacity-6"></span>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-5 text-center mx-auto">
            <h1 class="text-white mb-2 mt-5">SELAMAT DATANG!</h1>
            <p class="text-lead text-white">Gunakan formulir ini untuk membuat akun baru.</p>
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="row mt-lg-n10 mt-md-n11 mt-n10 justify-content-center">
        <div class="col-xl-4 col-lg-5 col-md-7 mx-auto">
          <div class="card z-index-0">
            <div class="card-header text-center pt-4">
              <h5>Registrasi</h5>
            </div>
            <div class="card-body">
              <?php if (isset($error)): ?>
                <p class="error text-danger"><?php echo $error; ?></p>
              <?php endif; ?>
              <?php if (isset($success)): ?>
                <p class="success text-success"><?php echo $success; ?></p>
              <?php endif; ?>
              <form method="post">
                <div class="mb-3" style="display: none;"><input type="number" class="form-control" value="<?= $last_id ?>" name="id" readonly /></div>
                <div class="mb-3"><input type="text" class="form-control" placeholder="Username" name="username" required /></div>
                <div class="mb-3"><input type="email" class="form-control" placeholder="Email" name="email" required /></div>
                <div class="mb-3"><input type="password" class="form-control" placeholder="Password" name="password" required /></div>
                <div class="mb-3"><input type="text" class="form-control" placeholder="Nama Lengkap" name="namalengkap" required /></div>
                <div class="mb-3"><input type="text" class="form-control" placeholder="Alamat" name="alamat" required /></div>
                <div class="mb-3">
                  <input type="text" name="level" id="level" value="peminjam" class="form-control" required readonly>
                </div>

                <div class="text-center">
                  <button type="submit" name="register" class="btn bg-gradient-dark w-100 my-4 mb-2">Daftar</button>
                </div>

                <p class="text-sm mt-3 mb-0">Sudah punya akun? <a href="../index.php" class="text-dark font-weight-bolder">Login</a></p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  <!-- -------- START FOOTER 3 w/ COMPANY DESCRIPTION WITH LINKS & SOCIAL ICONS & COPYRIGHT ------- -->
  <footer class="footer py-5">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mb-4 mx-auto text-center">
          <a
            href="javascript:;"
            target="_blank"
            class="text-secondary me-xl-5 me-3 mb-sm-0 mb-2">
            Company
          </a>
          <a
            href="javascript:;"
            target="_blank"
            class="text-secondary me-xl-5 me-3 mb-sm-0 mb-2">
            About Us
          </a>
          <a
            href="javascript:;"
            target="_blank"
            class="text-secondary me-xl-5 me-3 mb-sm-0 mb-2">
            Team
          </a>
          <a
            href="javascript:;"
            target="_blank"
            class="text-secondary me-xl-5 me-3 mb-sm-0 mb-2">
            Products
          </a>
          <a
            href="javascript:;"
            target="_blank"
            class="text-secondary me-xl-5 me-3 mb-sm-0 mb-2">
            Blog
          </a>
          <a
            href="javascript:;"
            target="_blank"
            class="text-secondary me-xl-5 me-3 mb-sm-0 mb-2">
            Pricing
          </a>
        </div>
        <div class="col-lg-8 mx-auto text-center mb-4 mt-2">
          <a
            href="javascript:;"
            target="_blank"
            class="text-secondary me-xl-4 me-4">
            <span class="text-lg fab fa-dribbble"></span>
          </a>
          <a
            href="javascript:;"
            target="_blank"
            class="text-secondary me-xl-4 me-4">
            <span class="text-lg fab fa-twitter"></span>
          </a>
          <a
            href="javascript:;"
            target="_blank"
            class="text-secondary me-xl-4 me-4">
            <span class="text-lg fab fa-instagram"></span>
          </a>
          <a
            href="javascript:;"
            target="_blank"
            class="text-secondary me-xl-4 me-4">
            <span class="text-lg fab fa-pinterest"></span>
          </a>
          <a
            href="javascript:;"
            target="_blank"
            class="text-secondary me-xl-4 me-4">
            <span class="text-lg fab fa-github"></span>
          </a>
        </div>
      </div>
      <div class="row">
        <div class="col-8 mx-auto text-center mt-1">
          <p class="mb-0 text-secondary">
            Copyright ©
            <script>
              document.write(new Date().getFullYear());
            </script>
            Soft by Creative Tim.
          </p>
        </div>
      </div>
    </div>
  </footer>
  <!-- -------- END FOOTER 3 w/ COMPANY DESCRIPTION WITH LINKS & SOCIAL ICONS & COPYRIGHT ------- -->
  <!--   Core JS Files   -->
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="../assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script>
    var win = navigator.platform.indexOf("Win") > -1;
    if (win && document.querySelector("#sidenav-scrollbar")) {
      var options = {
        damping: "0.5",
      };
      Scrollbar.init(document.querySelector("#sidenav-scrollbar"), options);
    }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/argon-dashboard.min.js?v=2.0.4"></script>
</body>

</html>