<?php
include "session.php";
include "../koneksi.php";

$search = "";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $query = "SELECT * FROM kategoribuku 
              WHERE id LIKE '%$search%' OR nama_kategori LIKE '%$search%'";
} else {
    $query = "SELECT * FROM kategoribuku";
}

$result = mysqli_query($koneksi, $query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        PERPUSTAKAAN RANCAGE
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="../assets/demo/demo.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
</head>

<body class="">
    <div class="wrapper">
        <div class="sidebar" data-color="white" data-active-color="info">
            <div class="logo">
                <a href="" class="simple-text logo-mini">
                    <div class="logo-image-mini">
                        <i class="fa-solid fa-book-open-reader text-primary"></i>
                    </div>
                </a>
                <a href="" class="h6 logo-normal text-primary" style="text-decoration: none;">
                    DASHBOARD ADMIN PERPUSTAKAAN RANCAGE

                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li>
                        <a href="./dashboard.php">
                            <i class="fa-solid fa-house-chimney"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li>
                        <a href="./buku.php">
                            <i class="fa-solid fa-book"></i>
                            <p>Buku</p>
                        </a>
                    </li>
                    <li>
                        <a href="./peminjaman.php">
                            <i class="fa-solid fa-book-bookmark"></i>
                            <p>Daftar Peminjaman</p>
                        </a>
                    </li>
                    <li>
                        <a href="./kunjungan.php">
                            <i class="fa-solid fa-person-walking-arrow-right"></i>
                            <p>Daftar Kunjungan</p>
                        </a>
                    </li>
                    <li>
                    <li>
                        <a href="./ulasan.php">
                            <i class="fa-solid fa-comments"></i>
                            <p>Ulasan Buku</p>
                        </a>
                    </li>
                    <li>
                        <a href="./user.php">
                            <i class="fa-solid fa-user"></i>
                            <p>User List</p>
                        </a>
                    </li>
                    <li class="active">
                        <a href="./kategori.php">
                            <i class="fa-solid fa-list"></i>
                            <p>Kategori</p>
                        </a>
                    </li>
                    <hr>
                    <li>
                        <a href="./logout.php" class="text-danger" onclick="return confirm('Apakah Anda yakin ingin Logout?')">
                            <i class="fa-solid fa-arrow-right-from-bracket text-danger"></i>
                            <p>Logout</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                        <a class="navbar-brand" href="javascript:;">Kategori</a>
                    </div>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <form action="" method="GET">
                            <div class="input-group no-border">
                                <?php if (!empty($search)) { ?>
                                    <div class="input-group-prepend">
                                        <a href="kategori.php" class="input-group-text">
                                            <i class="nc-icon nc-simple-remove"></i>
                                        </a>
                                    </div>
                                <?php } ?>
                                <input type="text" name="search" value="<?php echo $search; ?>" class="form-control" placeholder="Cari Kategori">
                                <div class="input-group-append">
                                    <button type="submit" class="input-group-text">
                                        <i class="nc-icon nc-zoom-split"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </nav>
            <!-- End Navbar -->

            <div class="content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">DAFTAR KATEGORI</h4>
                            </div>
                            <div class="card-body">
                                <a href="add_kategori.php"><button class="btn btn-info"><i class="fa-solid fa-add"></i> Tambah Kategori</button></a>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <th>ID KATEGORI</th>
                                            <th>NAMA KATEGORI</th>
                                            <th>AKSI</th>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if (mysqli_num_rows($result) > 0) {
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                    echo "<tr>";
                                                    echo "<td>" . $row['id'] . "</td>";
                                                    echo "<td>" . $row['nama_kategori'] . "</td>";
                                                    echo "<td>";
                                                    echo "<a href='edit_kategori.php?id=" . $row['id'] . "' class='btn btn-success btn-sm mb-1' title='Edit Kategori'><i class='fa-solid fa-pencil'></i></a> <br> ";
                                                    echo "<a href='hapus_kategori.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm' title='Hapus' onclick='return confirm(\"Apakah Anda yakin ingin menghapus buku ini?\");'><i class='fa-solid fa-trash'></i></a>";
                                                    echo "</td>";
                                                    echo "</tr>";
                                                }
                                            } else {
                                                echo "<tr><td colspan='7'>Tidak ada data yang ditemukan</td></tr>";  // Kolom total disesuaikan menjadi 7
                                            }
                                            ?>
                                        </tbody>

                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- Penutup Main Panel -->
    </div>
    <!--   Core JS Files   -->
    <script src="../assets/js/core/jquery.min.js"></script>
    <script src="../assets/js/tooltip.js"></script>
    <script src="../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap.min.js"></script>
    <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
    <!-- Chart JS -->
    <script src="../assets/js/plugins/chartjs.min.js"></script>
    <!--  Notifications Plugin    -->
    <script src="../assets/js/plugins/bootstrap-notify.js"></script>
    <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="../assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script>
    <!-- Paper Dashboard DEMO methods, don't include it in your project! -->
    <script src="../assets/demo/demo.js"></script>
</body>

</html>