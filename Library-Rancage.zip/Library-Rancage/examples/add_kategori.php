<?php
include '../koneksi.php';

if (isset($_POST['tambah'])) {
    $id = $_POST['id'];
    $nama_kategori = $_POST['nama_kategori'];

    $query = "INSERT INTO kategoribuku (id, nama_kategori) 
              VALUES ('$id', '$nama_kategori')";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Kategori berhasil ditambahkan!'); window.location='../examples/kategori.php';</script>";
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}

$sql = "SELECT MAX(id) AS last_id FROM kategoribuku";
$result = $koneksi->query($sql);
$row = $result->fetch_assoc();
$last_id = $row['last_id'] + 1;

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        PERPUSTAKAAN RANCAGE
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="../assets/demo/demo.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4>Tambah Buku</h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="mb-3">
                                <label for="id_buku" class="form-label">ID Kategori</label>
                                <input type="text" class="form-control" id="id" name="id" value="<?= $last_id ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="judul" class="form-label">Kategori</label>
                                <input type="text" class="form-control" id="nama_kategori" name="nama_kategori" placeholder="Masukkan Kategori" required>
                            </div>
                            <button type="submit" name="tambah" class="btn btn-success">Simpan</button>
                            <a href="kategori.php" class="btn btn-danger">Batal</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoIExlF5nqU93SKmZo7lr1luIs03M9WliH/2ZA/h2Bx0q2F" crossorigin="anonymous"></script>
</body>

</html>