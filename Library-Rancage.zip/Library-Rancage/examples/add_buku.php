<?php
include '../koneksi.php';
include "session.php";

if (isset($_POST['tambah'])) {
    // Ambil data dari form
    $id_buku = $_POST['id_buku'];
    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $penerbit = $_POST['penerbit'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $id_kategori = $_POST['kategoribuku']; // Ambil id_kategori dari form

    // Menangani upload gambar sampul
    $sampul = $_FILES['sampul']['name']; // Nama file sampul
    $targetDir = "../cover_buku/"; // Direktori tempat sampul disimpan
    $targetFile = $targetDir . basename($sampul);
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Validasi tipe file gambar (misalnya hanya jpg, png, jpeg yang diizinkan)
    $validExtensions = array('jpg', 'png', 'jpeg');
    if (in_array($imageFileType, $validExtensions)) {
        // Upload file sampul
        if (move_uploaded_file($_FILES['sampul']['tmp_name'], $targetFile)) {
            // Query untuk insert ke tabel buku
            $queryBuku = "INSERT INTO buku (id, judul, penulis, penerbit, tahun_terbit, sampul) 
                          VALUES ('$id_buku', '$judul', '$penulis', '$penerbit', '$tahun_terbit', '$sampul')";

            if (mysqli_query($koneksi, $queryBuku)) {
                // Buat ID baru untuk relasi kategoribuku_relasi
                $queryLastRelasiID = "SELECT MAX(id) AS last_id FROM kategoribuku_relasi";
                $resultRelasiID = $koneksi->query($queryLastRelasiID);
                $rowRelasiID = $resultRelasiID->fetch_assoc();
                $newRelasiID = $rowRelasiID['last_id'] + 1;

                // Jika berhasil insert ke tabel buku, lakukan insert ke tabel kategoribuku_relasi
                $queryRelasi = "INSERT INTO kategoribuku_relasi (id, buku_id, kategori_id) 
                                VALUES ('$newRelasiID', '$id_buku', '$id_kategori')";

                if (mysqli_query($koneksi, $queryRelasi)) {
                    echo "<script>alert('Buku berhasil ditambahkan dengan kategori!'); window.location='../examples/buku.php';</script>";
                } else {
                    echo "Error kategori: " . mysqli_error($koneksi);
                }
            } else {
                echo "Error buku: " . mysqli_error($koneksi);
            }
        } else {
            echo "Maaf, terjadi kesalahan saat mengupload file sampul.";
        }
    } else {
        echo "Hanya file gambar dengan ekstensi .jpg, .png, .jpeg yang diperbolehkan.";
    }
}

// Ambil id terakhir dan tambah 1 untuk id_buku baru
$sql = "SELECT MAX(id) AS last_id FROM buku";
$result = $koneksi->query($sql);
$row = $result->fetch_assoc();
$last_id = $row['last_id'] + 1;

// Ambil data kategori untuk dropdown
$queryKategori = "SELECT id, nama_kategori FROM kategoribuku";
$resultKategori = mysqli_query($koneksi, $queryKategori);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        PERPUSTAKAAN RANCAGE
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="../assets/demo/demo.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4>Tambah Buku</h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="sampul" class="form-label">Sampul Buku</label>
                                <input type="file" class="form-control" id="sampul" name="sampul">
                            </div>
                            <div class="mb-3">
                                <label for="id_buku" class="form-label">ID Buku</label>
                                <input type="text" class="form-control" id="id_buku" name="id_buku" value="<?= $last_id ?>" readonly>
                            </div>
                            <div class="mb-3">
                                <label for="kategoribuku" class="form-label">Kategori</label>
                                <select name="kategoribuku" id="kategoribuku" class="form-control" required>
                                    <option value="">Pilih Kategori</option>
                                    <?php while ($rowKategori = mysqli_fetch_assoc($resultKategori)) : ?>
                                        <option value="<?= $rowKategori['id']; ?>"><?= $rowKategori['nama_kategori']; ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="judul" class="form-label">Judul Buku</label>
                                <input type="text" class="form-control" id="judul" name="judul" placeholder="Masukkan judul buku" required>
                            </div>
                            <div class="mb-3">
                                <label for="penulis" class="form-label">Penulis</label>
                                <input type="text" class="form-control" id="penulis" name="penulis" placeholder="Masukkan nama penulis" required>
                            </div>
                            <div class="mb-3">
                                <label for="penerbit" class="form-label">Penerbit</label>
                                <input type="text" class="form-control" id="penerbit" name="penerbit" placeholder="Masukkan penerbit buku" required>
                            </div>
                            <div class="mb-3">
                                <label for="tahun_terbit" class="form-label">Tahun Terbit</label>
                                <input type="number" class="form-control" id="tahun_terbit" name="tahun_terbit" placeholder="Masukkan tahun terbit" required>
                            </div>
                            <button type="submit" name="tambah" class="btn btn-success">Tambah Buku</button>
                            <a href="buku.php" class="btn btn-danger">Batal</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoIExlF5nqU93SKmZo7lr1luIs03M9WliH/2ZA/h2Bx0q2F" crossorigin="anonymous"></script>
</body>

</html>