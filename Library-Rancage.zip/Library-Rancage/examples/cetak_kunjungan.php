<?php
include "../koneksi.php";
require 'vendor/autoload.php';

use Dompdf\Dompdf;

// Ambil semua data kunjungan beserta nama lengkap user
$query = "
    SELECT k.user_id, u.namalengkap, k.keperluan, k.tgl
    FROM kunjungan k
    JOIN user u ON k.user_id = u.id";

$result = mysqli_query($koneksi, $query);

// Periksa apakah data ditemukan
if (mysqli_num_rows($result) == 0) {
    die("Tidak ada data kunjungan yang ditemukan.");
}

// Inisialisasi Dompdf
$dompdf = new Dompdf();

// Membuat HTML untuk laporan
$html = '
    <div style="display: flex; align-items: center; margin-bottom: 20px;">
        <div style="margin-left: 10px;">
            <span style="font-size: 18px; font-weight: bold; color: #17a2b8;">PERPUSTAKAAN RANCAGE</span><br>
            <small style="font-size: 12px; color: #6c757d;">Jl. Pendidikan No. 123, Kota Buku</small>
        </div>
    </div>

    <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
        <thead>
            <tr style="background-color: #17a2b8; color: white; text-align: center;">
                <th style="padding: 8px; border: 1px solid #ddd; width: 5%;">User ID</th>
                <th style="padding: 8px; border: 1px solid #ddd; width: 15%;">Nama Lengkap</th>
                <th style="padding: 8px; border: 1px solid #ddd; width: 10%;">Keperluan</th>
                <th style="padding: 8px; border: 1px solid #ddd; width: 15%;">Tanggal</th>
            </tr>
        </thead>
        <tbody>';

// Tambahkan data ke tabel
while ($row = mysqli_fetch_assoc($result)) {
    $html .= '
        <tr style="background-color: #e9f7fc; text-align: center;">
            <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['user_id']) . '</td>
            <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['namalengkap']) . '</td>
            <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['keperluan']) . '</td>
            <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['tgl']) . '</td>
        </tr>';
}

$html .= '</tbody></table>';

// Load HTML ke Dompdf
$dompdf->loadHtml($html);

// Set ukuran dan orientasi kertas
$dompdf->setPaper('A4', 'landscape');

// Render PDF
$dompdf->render();

// Output ke browser
header("Content-Type: application/pdf");
$dompdf->stream('laporan_kunjungan.pdf', array('Attachment' => 0));
