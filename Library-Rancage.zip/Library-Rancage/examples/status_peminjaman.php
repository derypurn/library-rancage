<?php
include "../koneksi.php";

// Mendapatkan data dari form
$id = $_POST['id'];
$status = $_POST['status'];
$now = date("Y-m-d");

if ($status == 'dikembalikan') {
    // Jika status dikembalikan, update tgl_kembali
    $update_query = "UPDATE peminjaman SET status = '$status', tgl_kembali = '$now' WHERE id = $id";
} else {
    // Jika status dipinjam, tidak perlu mengupdate tgl_kembali
    $update_query = "UPDATE peminjaman SET status = '$status' WHERE id = $id";
}

if (mysqli_query($koneksi, $update_query)) {
    header("Location: peminjaman.php?success=1");
} else {
    echo "Error updating record: " . mysqli_error($koneksi);
}
