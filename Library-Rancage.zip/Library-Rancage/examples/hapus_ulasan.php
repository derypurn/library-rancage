<?php
include "session.php";
include "../koneksi.php";

$ulasan_id = isset($_GET['id']) ? $_GET['id'] : null;
if (!$ulasan_id) {
    echo "<script>alert('ID ulasan tidak ditemukan!'); window.location.href = 'ulasan.php';</script>";
    exit;
}

// Hapus ulasan berdasarkan ulasan_id dan user_id
$query = "DELETE FROM ulasan_buku WHERE id = '$ulasan_id'";
if (mysqli_query($koneksi, $query)) {
    echo "<script>alert('Ulasan berhasil dihapus.'); window.location.href = 'ulasan.php';</script>";
} else {
    echo "<script>alert('Gagal menghapus ulasan.'); window.location.href = 'ulasan.php';</script>";
}
