<?php
include "../koneksi.php";
require 'vendor/autoload.php';

use Dompdf\Dompdf;

// Periksa apakah parameter `id` diberikan
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("ID peminjaman tidak ditemukan.");
}

$id = intval($_GET['id']);

// Ambil data peminjaman berdasarkan ID
$query = "
    SELECT 
        peminjaman.id, 
        user.username, 
        user.email, 
        user.alamat, 
        buku.judul, 
        buku.penulis, 
        buku.penerbit, 
        buku.tahun_terbit, 
        peminjaman.tgl_pinjam, 
        peminjaman.tgl_kembali, 
        peminjaman.status,
        peminjaman.batas_pinjam  
    FROM peminjaman
    JOIN user ON peminjaman.user_id = user.id
    JOIN buku ON peminjaman.buku_id = buku.id
    WHERE peminjaman.id = $id";

$result = mysqli_query($koneksi, $query);

// Periksa apakah data ditemukan
if (mysqli_num_rows($result) == 0) {
    die("Data peminjaman tidak ditemukan.");
}

$row = mysqli_fetch_assoc($result);

// Hitung denda
$denda = 0;
$tgl_pinjam = new DateTime($row['tgl_pinjam']);
$tgl_kembali = empty($row['tgl_kembali']) ? null : new DateTime($row['tgl_kembali']);
$batas_pinjam = empty($row['batas_pinjam']) ? null : new DateTime($row['batas_pinjam']);
$tgl_sekarang = new DateTime();

if ($batas_pinjam) {
    if ($row['status'] == 'dipinjam' && $tgl_sekarang > $batas_pinjam) {
        $selisih = $tgl_sekarang->diff($batas_pinjam)->days;
        $denda = $selisih * 1000; // Denda Rp2.000 per hari
    } elseif ($row['status'] == 'dikembalikan' && $tgl_kembali > $batas_pinjam) {
        $selisih = $tgl_kembali->diff($batas_pinjam)->days;
        $denda = $selisih * 1000; // Denda Rp2.000 per hari
    }
}

// Inisialisasi Dompdf
$dompdf = new Dompdf();

// Membuat HTML untuk laporan
$html = '
    <div style="display: flex; align-items: center; margin-bottom: 20px;">
        <div style="margin-left: 10px;">
            <span style="font-size: 18px; font-weight: bold; color: #17a2b8;">PERPUSTAKAAN RANCAGE</span><br>
            <small style="font-size: 12px; color: #6c757d;">Jl. Pendidikan No. 123, Kota Buku</small>
        </div>
    </div>
    <br>
   <table style="width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 20px;">
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold; width: 30%;">ID Peminjaman</td>
        <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['id']) . '</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold;">Username</td>
        <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['username']) . '</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold;">Email</td>
        <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['email']) . '</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold;">Alamat</td>
        <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['alamat']) . '</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold;">Judul Buku</td>
        <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['judul']) . '</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold;">Penulis</td>
        <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['penulis']) . '</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold;">Penerbit</td>
        <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['penerbit']) . '</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold;">Tahun Terbit</td>
        <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['tahun_terbit']) . '</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold;">Tanggal Pinjam</td>
        <td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($row['tgl_pinjam']) . '</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold;">Tanggal Kembali</td>
        <td style="padding: 8px; border: 1px solid #ddd;">' . (!empty($row['tgl_kembali']) ? htmlspecialchars($row['tgl_kembali']) : '') . '</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold;">Status</td>
        <td style="padding: 8px; border: 1px solid #ddd;">' . ucfirst(htmlspecialchars($row['status'])) . '</td>
    </tr>
    <tr>
        <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f9fa; font-weight: bold;">Denda</td>
        <td style="padding: 8px; border: 1px solid #ddd;">Rp' . number_format($denda, 0, ',', '.') . '</td>
    </tr>
</table>
';

// Debugging HTML
// echo $html;
// exit;

// Load HTML ke Dompdf
$dompdf->loadHtml($html);

// Set ukuran dan orientasi kertas
$dompdf->setPaper('A4', 'portrait');

// Render PDF
$dompdf->render();

// Output ke browser
header("Content-Type: application/pdf");
$dompdf->stream('laporan_peminjaman_' . $row['id'] . '.pdf', array('Attachment' => 0));
