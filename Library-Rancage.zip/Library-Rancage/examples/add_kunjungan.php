<?php
include '../koneksi.php';
include "session.php";

date_default_timezone_set("Asia/Jakarta");
// Ambil data user untuk dropdown
$queryUsers = "SELECT id, namalengkap FROM user";
$resultUsers = mysqli_query($koneksi, $queryUsers);

// Ambil enum keperluan dari struktur tabel kunjungan
$queryKeperluan = "SHOW COLUMNS FROM kunjungan LIKE 'keperluan'";
$resultKeperluan = mysqli_query($koneksi, $queryKeperluan);
$rowKeperluan = mysqli_fetch_assoc($resultKeperluan);
$enumKeperluan = str_replace(["enum(", ")", "'"], "", $rowKeperluan['Type']);
$optionsKeperluan = explode(",", $enumKeperluan);

if (isset($_POST['tambah'])) {
    $user_id = $_POST['user_id'];
    $keperluan = $_POST['keperluan'];
    $tgl = date('Y-m-d H:i:s');

    // Insert ke tabel kunjungan
    $queryInsert = "INSERT INTO kunjungan (user_id, keperluan, tgl) VALUES ('$user_id', '$keperluan', '$tgl')";
    if (mysqli_query($koneksi, $queryInsert)) {
        echo "<script>alert('Kunjungan berhasil ditambahkan!'); window.location.href='kunjungan.php';</script>";
    } else {
        echo "<script>alert('Terjadi kesalahan, coba lagi.'); window.location.href='add_kunjungan.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        PERPUSTAKAAN RANCAGE
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="../assets/demo/demo.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4>Tambah Kunjungan</h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST" enctype="multipart/form-data">
                            <div class="mb-3">
                                <label for="user_id" class="form-label">Nama Lengkap</label>
                                <select name="user_id" id="user_id" class="form-control" required>
                                    <option value="">Pilih Nama</option>
                                    <?php while ($rowUser = mysqli_fetch_assoc($resultUsers)) : ?>
                                        <option value="<?= $rowUser['id']; ?>"><?= $rowUser['namalengkap']; ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="keperluan" class="form-label">Keperluan</label>
                                <select name="keperluan" id="keperluan" class="form-control" required>
                                    <option value="">Pilih Keperluan</option>
                                    <?php foreach ($optionsKeperluan as $option) : ?>
                                        <option value="<?= $option; ?>"><?= $option; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <button type="submit" name="tambah" class="btn btn-success">Tambah Kunjungan</button>
                            <a href="kunjungan.php" class="btn btn-danger">Batal</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoIExlF5nqU93SKmZo7lr1luIs03M9WliH/2ZA/h2Bx0q2F" crossorigin="anonymous"></script>
</body>

</html>