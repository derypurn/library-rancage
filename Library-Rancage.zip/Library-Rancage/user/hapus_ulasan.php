<?php
include "session.php";
include "../koneksi.php";

// Ambil user_id dari session
$email = $_SESSION['email'];
$query_user = "SELECT id FROM user WHERE email = '$email'";
$result_user = mysqli_query($koneksi, $query_user);
$user_data = mysqli_fetch_assoc($result_user);
$user_id = $user_data['id'];

// Ambil ulasan_id dari URL
$ulasan_id = isset($_GET['id']) ? $_GET['id'] : null;
if (!$ulasan_id) {
    echo "<script>alert('ID ulasan tidak ditemukan!'); window.location.href = 'ulasan.php';</script>";
    exit;
}

// Hapus ulasan berdasarkan ulasan_id dan user_id
$query = "DELETE FROM ulasan_buku WHERE id = '$ulasan_id' AND user_id = '$user_id'";
if (mysqli_query($koneksi, $query)) {
    echo "<script>alert('Ulasan berhasil dihapus.'); window.location.href = 'ulasan.php';</script>";
} else {
    echo "<script>alert('Gagal menghapus ulasan.'); window.location.href = 'ulasan.php';</script>";
}
