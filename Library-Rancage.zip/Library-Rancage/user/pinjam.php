<?php
include "../koneksi.php";
include "session.php";


// Ambil ID buku dari URL
if (isset($_GET['id'])) {
    $buku_id = $_GET['id'];
    // Query untuk mengambil data buku berdasarkan id
    $query = "SELECT * FROM buku WHERE id = '$buku_id'";
    $result = mysqli_query($koneksi, $query);
    $data_buku = mysqli_fetch_assoc($result);

    // Periksa apakah data buku ditemukan
    if (!$data_buku) {
        die("Buku tidak ditemukan.");
    }
} else {
    die("ID buku tidak ada.");
}

// Ambil data user dari session
$username = $_SESSION['username'];
$email = $_SESSION['email'];
$alamat = $_SESSION['alamat'];

// Set tanggal pinjam dan batas pinjam
$tgl_pinjam = date("Y-m-d");
$batas_pinjam = date("Y-m-d", strtotime("+7 days"));

// Proses konfirmasi peminjaman
if (isset($_POST['konfirmasi_peminjaman'])) {
    $email = $_SESSION['email'];
    $query_user = "SELECT id FROM user WHERE email = '$email'";
    $result_user = mysqli_query($koneksi, $query_user);
    $user_data = mysqli_fetch_assoc($result_user);
    $user_id = $user_data['id'];

    // Query untuk menambahkan data ke tabel peminjaman dengan NULL untuk tgl_kembali
    $insert_query = "INSERT INTO peminjaman (user_id, buku_id, tgl_pinjam, batas_pinjam, tgl_kembali, status)
                     VALUES ('$user_id', '$buku_id', '$tgl_pinjam', '$batas_pinjam', NULL, 'dipinjam')";

    if (mysqli_query($koneksi, $insert_query)) {
        echo "<script>alert('Peminjaman berhasil!'); window.location.href='peminjaman.php';</script>";
    } else {
        echo "<script>alert('Peminjaman gagal!');</script>";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        PERPUSTAKAAN RANCAGE
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="../assets/demo/demo.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
</head>

<body class="">
    <div class="wrapper">
        <div class="sidebar" data-color="white" data-active-color="primary">
            <div class="logo">
                <a href="" class="simple-text logo-mini">
                    <div class="logo-image-mini">
                        <i class="fa-solid fa-book-open-reader text-primary"></i>
                    </div>
                </a>
                <a href="" class="h6 logo-normal text-primary" style="text-decoration: none;">
                    PERPUSTAKAAN RANCAGE

                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li>
                        <a href="./dashboard.php">
                            <i class="fa-solid fa-house-chimney"></i>
                            <p>Beranda</p>
                        </a>
                    </li>
                    <li>
                        <a href="./buku.php">
                            <i class="fa-solid fa-book"></i>
                            <p>Daftar Buku</p>
                        </a>
                    </li>
                    <li>
                        <a href="./koleksibuku.php">
                            <i class="fa-solid fa-book-bookmark"></i>
                            <p>Koleksi Pribadi</p>
                        </a>
                    </li>
                    <li class="active">
                        <a href="./peminjaman.php">
                            <i class="fa-solid fa-clock-rotate-left"></i>
                            <p>Histori Peminjaman</p>
                        </a>
                    </li>
                    <li>
                        <a href="./kunjungan.php">
                            <i class="fa-solid fa-person-walking-arrow-right"></i>
                            <p>Histori Kunjungan</p>
                        </a>
                    </li>
                    <li>
                    <li>
                        <a href="./ulasan.php">
                            <i class="fa-solid fa-comments"></i>
                            <p>Ulasan Anda</p>
                        </a>
                    </li>
                    <li>
                        <a href="./user.php">
                            <i class="fa-solid fa-user"></i>
                            <p>Profile</p>
                        </a>
                    </li>
                    <li>
                        <a href="./terms.php">
                            <i class="fa-solid fa-circle-info"></i>
                            <p>Syarat & Ketentuan</p>
                        </a>
                    </li>
                    <hr>
                    <li>
                        <a href="./logout.php" class="text-danger" onclick="return confirm('Apakah Anda yakin ingin Logout?')">
                            <i class="fa-solid fa-arrow-right-from-bracket text-danger"></i>
                            <p>Logout</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
            <nav
                class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                        <a class="navbar-brand" href="javascript:;">Beranda</a>
                    </div>
                    <button
                        class="navbar-toggler"
                        type="button"
                        data-toggle="collapse"
                        data-target="#navigation"
                        aria-controls="navigation-index"
                        aria-expanded="false"
                        aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                    </button>
                    <div
                        class="collapse navbar-collapse justify-content-end"
                        id="navigation">
                        <form>
                            <div class="input-group no-border">
                                <input
                                    type="text"
                                    value=""
                                    class="form-control"
                                    placeholder="Search..." />
                                <div class="input-group-append">
                                    <div class="input-group-text">
                                        <i class="nc-icon nc-zoom-split"></i>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link btn-magnify" href="javascript:;">
                                    <i class="nc-icon nc-layout-11"></i>
                                    <p>
                                        <span class="d-lg-none d-md-block">Stats</span>
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item btn-rotate dropdown">
                                <a
                                    class="nav-link dropdown-toggle"
                                    href="http://example.com"
                                    id="navbarDropdownMenuLink"
                                    data-toggle="dropdown"
                                    aria-haspopup="true"
                                    aria-expanded="false">
                                    <i class="nc-icon nc-bell-55"></i>
                                    <p>
                                        <span class="d-lg-none d-md-block">Some Actions</span>
                                    </p>
                                </a>
                                <div
                                    class="dropdown-menu dropdown-menu-right"
                                    aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <a class="dropdown-item" href="#">Something else here</a>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn-rotate" href="javascript:;">
                                    <i class="nc-icon nc-settings-gear-65"></i>
                                    <p>
                                        <span class="d-lg-none d-md-block">Account</span>
                                    </p>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- End Navbar -->
            <div class="content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h2>Rincian Peminjaman Buku</h2>
                            </div>
                            <div class="card-body">
                                <h3>Data Peminjam</h3>
                                <p>
                                    <strong>Username:</strong>
                                    <?php echo $username; ?>
                                </p>
                                <p>
                                    <strong>Email:</strong>
                                    <?php echo $email; ?>
                                </p>
                                <p>
                                    <strong>Alamat:</strong>
                                    <?php echo $alamat; ?>
                                </p>

                                <!-- Tampilkan rincian buku -->
                                <h3>Data Buku</h3>
                                <p>
                                    <strong>Judul Buku:</strong>
                                    <?php echo $data_buku['judul']; ?>
                                </p>
                                <p>
                                    <strong>Penulis:</strong>
                                    <?php echo $data_buku['penulis']; ?>
                                </p>
                                <p>
                                    <strong>Penerbit:</strong>
                                    <?php echo $data_buku['penerbit']; ?>
                                </p>
                                <p>
                                    <strong>Tahun Terbit:</strong>
                                    <?php echo $data_buku['tahun_terbit']; ?>
                                </p>

                                <!-- Tampilkan tanggal pinjam dan batas pinjam -->
                                <h3>Tanggal Peminjaman</h3>
                                <p>
                                    <strong>Tanggal Pinjam:</strong>
                                    <?php echo $tgl_pinjam; ?>
                                </p>
                                <p>
                                    <strong>Batas Pinjam:</strong>
                                    <?php echo $batas_pinjam; ?>
                                </p>

                                <!-- Tombol konfirmasi peminjaman -->
                                <form method="POST">
                                    <button
                                        type="submit"
                                        name="konfirmasi_peminjaman"
                                        class="btn btn-success mt-3">
                                        Konfirmasi Peminjaman
                                    </button>
                                    <a href="buku.php" class="btn btn-danger mt-3">Batalkan</a>
                                </form>
                            </div>
                        </div>
                        <div class="card-footer">
                            <hr />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="footer footer-black footer-white">
            <div class="container-fluid">
                <div class="row">
                    <nav class="footer-nav">
                        <ul>
                            <li>
                                <a href="https://www.creative-tim.com" target="_blank">Creative Tim</a>
                            </li>
                            <li>
                                <a href="https://www.creative-tim.com/blog" target="_blank">Blog</a>
                            </li>
                            <li>
                                <a
                                    href="https://www.creative-tim.com/license"
                                    target="_blank">Licenses</a>
                            </li>
                        </ul>
                    </nav>
                    <div class="credits ml-auto">
                        <span class="copyright">
                            ©
                            <script>
                                document.write(new Date().getFullYear());
                            </script>
                            , made with <i class="fa fa-heart heart"></i> by Creative Tim
                        </span>
                    </div>
                </div>
            </div>
            <footer class="footer footer-black  footer-white ">
                <div class="container-fluid">
                    <div class="row">
                        <div class="credits ml-auto">
                            <span class="copyright">
                                © <script>
                                    document.write(new Date().getFullYear())
                                </script> PERPUSTAKAAN RANCAGE
                            </span>
                        </div>
                    </div>
                </div>
            </footer>
    </div>
    </div>
    <!--   Core JS Files   -->
    <script src="../assets/js/core/jquery.min.js"></script>
    <script src="../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap.min.js"></script>
    <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
    <!--  Google Maps Plugin    -->
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
    <!-- Chart JS -->
    <script src="../assets/js/plugins/chartjs.min.js"></script>
    <!--  Notifications Plugin    -->
    <script src="../assets/js/plugins/bootstrap-notify.js"></script>
    <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
    <script
        src="../assets/js/paper-dashboard.min.js?v=2.0.1"
        type="text/javascript"></script>
    <!-- Paper Dashboard DEMO methods, don't include it in your project! -->
    <script src="../assets/demo/demo.js"></script>
    <script>
        $(document).ready(function() {
            // Javascript method's body can be found in assets/assets-for-demo/js/demo.js
            demo.initChartsPages();
        });
    </script>
</body>

</html>