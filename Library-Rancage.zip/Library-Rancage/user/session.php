<?php
session_start();
if (!isset($_SESSION['email'])) {
    echo "<script>alert('Anda tidak memiliki akses kesini, Harap Login!'); window.location.href = '../index.php';</script>";
}

if ($_SESSION['level'] !== 'peminjam') {
    echo "<script>alert('Anda tidak memiliki akses kesini, Harap Login!'); window.location.href = '../index.php';</script>";
}
