<?php
include "session.php"; // Memastikan session diaktifkan
include "../koneksi.php";

// Ambil user_id dari session
$email = $_SESSION['email'];
$query_user = "SELECT id FROM user WHERE email = '$email'";
$result_user = mysqli_query($koneksi, $query_user);
$user_data = mysqli_fetch_assoc($result_user);
$user_id = $user_data['id'];

// Ambil buku_id dari URL dan pastikan tidak kosong
$buku_id = isset($_GET['buku_id']) ? $_GET['buku_id'] : null;
if (!$buku_id) {
    echo "<script>alert('Buku ID tidak ditemukan!'); window.location.href = 'buku.php';</script>";
    exit;
}

// Query untuk menambahkan buku ke koleksi pribadi
$query_koleksi = "INSERT INTO koleksipribadi (user_id, buku_id) VALUES ('$user_id', '$buku_id')";

// Eksekusi query
if (mysqli_query($koneksi, $query_koleksi)) {
    echo "<script>alert('Buku berhasil ditambahkan ke koleksi pribadi!'); window.location.href = 'koleksibuku.php';</script>";
} else {
    echo "<script>alert('Gagal menambahkan buku ke koleksi.'); window.location.href = 'buku.php';</script>";
}
