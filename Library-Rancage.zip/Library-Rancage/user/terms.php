<?php
include "session.php"; // Memastikan user sudah login
include "../koneksi.php"; // Koneksi ke database

$email = $_SESSION['email']; // Ambil email dari session

// Cek apakah email ada di session
if (!isset($email)) {
    die("Anda belum login.");
}

// Query untuk mengambil data pengguna
$query_user = "SELECT * FROM user WHERE email = ?";
$stmt = $koneksi->prepare($query_user);
$stmt->bind_param("s", $email); // Bind parameter email
$stmt->execute(); // Eksekusi query
$result_user = $stmt->get_result(); // Ambil hasil

// Cek jika ada pengguna yang ditemukan
if ($result_user->num_rows > 0) {
    $userData = $result_user->fetch_assoc(); // Ambil data pengguna
} else {
    die("Pengguna tidak ditemukan.");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        PERPUSTAKAAN RANCAGE
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="../assets/demo/demo.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
    <script>
        function toggleEdit() {
            var inputs = document.querySelectorAll('.form-control');
            var editButton = document.getElementById('editButton');
            var saveButton = document.getElementById('saveButton'); // Ambil tombol simpan
            var isReadonly = inputs[0].readOnly; // Cek apakah input saat ini dalam keadaan readonly

            inputs.forEach(function(input, index) {
                if (index !== 4) { // Skip level (indeks 4)
                    input.readOnly = !isReadonly; // Ubah status readonly
                }
            });

            // Ubah teks tombol sesuai status edit
            if (isReadonly) {
                editButton.innerText = 'X';
                editButton.classList.remove('btn-warning');
                editButton.classList.add('btn-danger');
                saveButton.disabled = false; // Aktifkan tombol simpan
            } else {
                editButton.innerText = 'EDIT';
                editButton.classList.remove('btn-success');
                editButton.classList.add('btn-warning');
                saveButton.disabled = true; // Nonaktifkan tombol simpan
            }
        }
    </script>

</head>

<body>
    <div class="wrapper">
        <div class="sidebar" data-color="white" data-active-color="primary">
            <div class="logo">
                <a href="" class="simple-text logo-mini">
                    <div class="logo-image-mini">
                        <i class="fa-solid fa-book-open-reader text-primary"></i>
                    </div>
                </a>
                <a href="" class="h6 logo-normal text-primary" style="text-decoration: none;">
                    PERPUSTAKAAN RANCAGE
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li>
                        <a href="./dashboard.php">
                            <i class="fa-solid fa-house-chimney"></i>
                            <p>Beranda</p>
                        </a>
                    </li>
                    <li>
                        <a href="./buku.php">
                            <i class="fa-solid fa-book"></i>
                            <p>Daftar Buku</p>
                        </a>
                    </li>
                    <li>
                        <a href="./koleksibuku.php">
                            <i class="fa-solid fa-book-bookmark"></i>
                            <p>Koleksi Pribadi</p>
                        </a>
                    </li>
                    <li>
                        <a href="./peminjaman.php">
                            <i class="fa-solid fa-clock-rotate-left"></i>
                            <p>Histori Peminjaman</p>
                        </a>
                    </li>
                    <li>
                        <a href="./kunjungan.php">
                            <i class="fa-solid fa-person-walking-arrow-right"></i>
                            <p>Histori Kunjungan</p>
                        </a>
                    </li>
                    <li>
                    <li>
                        <a href="./ulasan.php">
                            <i class="fa-solid fa-comments"></i>
                            <p>Ulasan Anda</p>
                        </a>
                    </li>
                    <li>
                        <a href="./user.php">
                            <i class="fa-solid fa-user"></i>
                            <p>Profile</p>
                        </a>
                    </li>
                    <li class="active">
                        <a href="./terms.php">
                            <i class="fa-solid fa-circle-info"></i>
                            <p>Syarat & Ketentuan</p>
                        </a>
                    </li>
                    <hr>
                    <li>
                        <a href="./logout.php" class="text-danger" onclick="return confirm('Apakah Anda yakin ingin Logout?')">
                            <i class="fa-solid fa-arrow-right-from-bracket text-danger"></i>
                            <p>Logout</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <a class="navbar-brand" href="javascript:;">Syarat dan Ketentuan</a>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                    </button>
                </div>
            </nav>
            <!-- End Navbar -->
            <div class="content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Syarat dan Ketentuan Peminjam, Peminjaman dan Penggunaan Aplikasi</h4>
                            </div>
                            <div class="card-body">
                                <p class="h5"><strong>Peminjam</strong></p>
                                <ul>
                                    <li>Peminjam harus terdaftar sebagai anggota resmi Perpustakaan RANCAGE.</li>
                                    <li>Anggota diwajibkan untuk menunjukkan identitas atau kartu anggota saat melakukan peminjaman.</li>
                                    <li>Peminjam bertanggung jawab menjaga kondisi buku atau materi lain yang dipinjam dari perpustakaan.</li>
                                    <li>Peminjam setuju untuk tidak memindahbukukan atau meminjamkan kembali buku yang telah dipinjam kepada pihak lain.</li>
                                    <li>Peminjam diwajibkan untuk memberitahukan perpustakaan jika terdapat kerusakan atau kehilangan buku.</li>
                                </ul>

                                <p class="h5 mt-4"><strong>Peminjaman</strong></p>
                                <ul>
                                    <li>Setiap peminjaman dikenakan biaya yang disesuaikan dengan jenis buku dan durasi peminjaman.</li>
                                    <li>Buku dapat dipinjam maksimal selama 7 hari. Jika diperlukan perpanjangan, anggota harus mengajukan sebelum batas waktu peminjaman berakhir.</li>
                                    <li>Perpanjangan peminjaman hanya dapat dilakukan sebanyak satu kali untuk setiap buku yang dipinjam, dengan durasi tambahan maksimal 7 hari.</li>
                                    <li>Jika buku tidak dikembalikan tepat waktu, peminjam akan dikenakan denda keterlambatan sebesar Rp1.000 per hari.</li>
                                    <li>Kerusakan atau kehilangan buku akan dikenakan biaya penggantian sesuai dengan nilai buku yang ditetapkan oleh perpustakaan.</li>
                                    <li>Peminjaman buku terbatas untuk kategori tertentu yang ditentukan oleh perpustakaan.</li>
                                    <li>Pihak perpustakaan berhak menolak permohonan peminjaman jika buku yang diminta tidak tersedia atau jika peminjam tidak memenuhi ketentuan.</li>
                                </ul>

                                <p class="h5 mt-4"><strong>Penggunaan Aplikasi</strong></p>
                                <ul>
                                    <li>Peminjam wajib melakukan login terlebih dahulu untuk mengakses layanan peminjaman buku melalui aplikasi.</li>
                                    <li>Data pribadi yang dimasukkan pada aplikasi harus sesuai dengan identitas asli peminjam dan digunakan sesuai ketentuan perpustakaan.</li>
                                    <li>Proses peminjaman dilakukan melalui aplikasi, termasuk memilih buku, mengonfirmasi peminjaman, dan mengecek histori peminjaman.</li>
                                    <li>Peminjam bertanggung jawab untuk menjaga kerahasiaan akun dan kata sandi yang digunakan untuk mengakses aplikasi.</li>
                                    <li>Jika peminjam menemukan kesalahan data pada akun atau transaksi, segera laporkan kepada admin perpustakaan untuk diperbaiki.</li>
                                    <li>Setiap pelanggaran atau penyalahgunaan aplikasi dapat mengakibatkan penangguhan akses layanan peminjaman atau sanksi lainnya sesuai kebijakan perpustakaan.</li>
                                    <li>Aplikasi hanya boleh digunakan untuk keperluan yang sesuai dengan ketentuan perpustakaan; tindakan ilegal atau tidak sah lainnya akan dikenakan sanksi.</li>
                                </ul>
                            </div>
                        </div>
                        <footer class="footer footer-black footer-white">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="credits ml-auto">
                                        <span class="copyright">
                                            © <script>
                                                document.write(new Date().getFullYear())
                                            </script> PERPUSTAKAAN RANCAGE
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </footer>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</body>

</html>