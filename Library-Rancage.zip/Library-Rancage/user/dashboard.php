<?php
include "session.php";
include "../koneksi.php";

$email = $_SESSION['email'];

$username = $_SESSION['username'];
$alamat = $_SESSION['alamat'];
// Query untuk mendapatkan id berdasarkan email
$query = "SELECT id FROM user WHERE email = '$email'";
$result = mysqli_query($koneksi, $query);

if ($result) {
  $row = mysqli_fetch_assoc($result);
  $user_id = $row['id']; // Simpan id user ke variabel
} else {
  echo "Error: " . mysqli_error($koneksi);
}

$query_nama = "SELECT namalengkap FROM user WHERE email = '$email'";
$result_nama = mysqli_query($koneksi, $query_nama);

if ($result_nama) {
  $row_nama = mysqli_fetch_assoc($result_nama);
  $namalengkap = $row_nama['namalengkap']; // Simpan id user ke variabel
} else {
  echo "Error: " . mysqli_error($koneksi);
}



$query_koleksi = "SELECT COUNT(*) AS total FROM koleksipribadi WHERE user_id  = '$user_id'";
$result_koleksi = mysqli_query($koneksi, $query_koleksi);
$row_koleksi = mysqli_fetch_assoc($result_koleksi);
$total_koleksi = $row_koleksi['total'];

$query_buku = "SELECT COUNT(*) AS total FROM buku";
$result_buku = mysqli_query($koneksi, $query_buku);
$row_buku = mysqli_fetch_assoc($result_buku);
$total_buku = $row_buku['total'];

$query_pinjaman = "SELECT COUNT(*) AS total FROM peminjaman WHERE user_id  = '$user_id'";
$result_pinjaman = mysqli_query($koneksi, $query_pinjaman);
$row_pinjaman = mysqli_fetch_assoc($result_pinjaman);
$total_pinjaman = $row_pinjaman['total'];

$query_ulasan = "SELECT COUNT(*) AS total FROM ulasan_buku WHERE user_id  = '$user_id'";
$result_ulasan = mysqli_query($koneksi, $query_ulasan);
$row_ulasan = mysqli_fetch_assoc($result_ulasan);
$total_ulasan = $row_ulasan['total'];

$query_buku_terpopuler = "
    SELECT 
        b.judul, 
        b.penerbit, 
        k.nama_kategori, 
        COUNT(p.buku_id) AS total_peminjaman,
        b.sampul   -- Add this line to select the cover image
    FROM peminjaman p
    JOIN buku b ON p.buku_id = b.id
    JOIN kategoribuku_relasi kr ON b.id = kr.buku_id
    JOIN kategoribuku k ON kr.kategori_id = k.id
    GROUP BY b.id, k.nama_kategori
    ORDER BY total_peminjaman DESC
    LIMIT 8";

$result_buku_terpopuler = mysqli_query($koneksi, $query_buku_terpopuler);

// Check if the query executed successfully
if (!$result_buku_terpopuler) {
  die('Query Error: ' . mysqli_error($koneksi));
} else {
  // Fetch all the results into the $buku_terpopuler variable
  $buku_terpopuler = mysqli_fetch_all($result_buku_terpopuler, MYSQLI_ASSOC);
}

// Check if the array is empty or not
if (empty($buku_terpopuler)) {
  echo "No popular books found.";
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    PERPUSTAKAAN RANCAGE
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <link href="../assets/demo/demo.css" rel="stylesheet" />
  <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
</head>

<body style="background-color: white;">
  <div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="primary">
      <div class="logo">
        <a href="" class="simple-text logo-mini">
          <div class="logo-image-mini">
            <i class="fa-solid fa-book-open-reader text-primary"></i>
          </div>
        </a>
        <a href="" class="h6 logo-normal text-primary" style="text-decoration: none;">
          PERPUSTAKAAN RANCAGE

        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="active">
            <a href="./dashboard.php">
              <i class="fa-solid fa-house-chimney"></i>
              <p>Beranda</p>
            </a>
          </li>
          <li>
            <a href="./buku.php">
              <i class="fa-solid fa-book"></i>
              <p>Daftar Buku</p>
            </a>
          </li>
          <li>
            <a href="./koleksibuku.php">
              <i class="fa-solid fa-book-bookmark"></i>
              <p>Koleksi Pribadi</p>
            </a>
          </li>
          <li>
            <a href="./peminjaman.php">
              <i class="fa-solid fa-clock-rotate-left"></i>
              <p>Histori Peminjaman</p>
            </a>
          </li>
          <li>
            <a href="./kunjungan.php">
              <i class="fa-solid fa-person-walking-arrow-right"></i>
              <p>Histori Kunjungan</p>
            </a>
          </li>
          <li>
          <li>
            <a href="./ulasan.php">
              <i class="fa-solid fa-comments"></i>
              <p>Ulasan Anda</p>
            </a>
          </li>
          <li>
            <a href="./user.php">
              <i class="fa-solid fa-user"></i>
              <p>Profile</p>
            </a>
          </li>
          <li>
            <a href="./terms.php">
              <i class="fa-solid fa-circle-info"></i>
              <p>Syarat & Ketentuan</p>
            </a>
          </li>
          <hr>
          <li>
            <a href="./logout.php" class="text-danger" onclick="return confirm('Apakah Anda yakin ingin Logout?')">
              <i class="fa-solid fa-arrow-right-from-bracket text-danger"></i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="javascript:;">Beranda</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navigation">
            <ul class="navbar-nav">
              <li class="nav-item btn-rotate dropdown">
                <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="fa-regular fa-user"></i>
                  <p>
                    <span class="d-lg-none d-md-block">Profile</span>
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="user.php">Profile</a>
                  <a class="dropdown-item" href="logout.php">Logout</a>
                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link btn-rotate" href="javascript:;">
                  <i class="fa-solid fa-circle-info"></i>
                  <p>
                    <span class="d-lg-none d-md-block">Syarat & Ketentuan</span>
                  </p>
                </a>
              </li>
              <li class="nav-item btn-rotate dropdown">
                <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="fa-solid fa-bars"></i>
                  <p>
                    <span class="d-lg-none d-md-block">Navigasi</span>
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="peminjaman.php">Histori Peminjaman</a>
                  <a class="dropdown-item" href="koleksibuku.php">Koleksi Pribadi</a>
                  <a class="dropdown-item" href="ulasan.php">Ulasan Anda</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card ">
              <div class="card-header">
                <h5 class="card-title m-4 text-primary"><strong>Selamat datang <?php echo $namalengkap; ?>, di Perpustakaan Rancage!</strong> </h5>
                <hr>
                <p class=" m-4 ">Kami sangat senang Anda berada di sini. Perpustakaan Rancage adalah tempat di mana pengetahuan dan imajinasi bertemu. Kami mengundang Anda untuk menjelajahi berbagai koleksi buku yang menarik, dari sejarah, religi, novel, romance, fiksi dan non-fiksi, serta materi pendidikan yang dapat memperluas wawasan Anda.
                  <br><br> Selamat membaca dan nikmati setiap halaman!
                </p>

              </div>
            </div>
          </div>
          <div class="row  m-1">
            <div class="col-lg-3 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-body">
                  <div class="row">
                    <div class="col-5 col-md-4">
                      <div class="icon-big text-center icon-warning">
                        <i class="fa-solid fa-book text-primary"></i>
                      </div>
                    </div>
                    <div class="col-7 col-md-8">
                      <div class="numbers">
                        <p class="card-category">Total Buku Perpustakan</p>
                        <p class="card-title"><?php echo $total_buku; ?>
                        <p>
                      </div>
                    </div>
                  </div>
                </div>
                <hr>
                <div class="card-footer ">
                  <a href="buku.php"><i class="fa-solid fa-circle-info"></i> Lihat detail</a>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-body ">
                  <div class="row">
                    <div class="col-5 col-md-4">
                      <div class="icon-big text-center icon-warning">
                        <i class="fa-solid fa-book-open text-primary"></i>
                      </div>
                    </div>
                    <div class="col-7 col-md-8">
                      <div class="numbers">
                        <p class="card-category">Buku yang anda pinjam</p>
                        <p class="card-title"><?php echo $total_pinjaman; ?>
                        <p>
                      </div>
                    </div>
                  </div>
                </div>
                <hr>
                <div class="card-footer ">
                  <a href="peminjaman.php"><i class="fa-solid fa-circle-info"></i> Lihat detail</a>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-body ">
                  <div class="row">
                    <div class="col-5 col-md-4">
                      <div class="icon-big text-center icon-warning">
                        <i class="fa-solid fa-book-bookmark text-primary"></i>
                      </div>
                    </div>
                    <div class="col-7 col-md-8">
                      <div class="numbers">
                        <p class="card-category">Koleksi Buku Anda</p>
                        <p class="card-title"><?php echo $total_koleksi; ?>
                        <p>
                      </div>
                    </div>
                  </div>
                </div>
                <hr>
                <div class="card-footer ">
                  <a href="koleksibuku.php"><i class="fa-solid fa-circle-info"></i> Lihat detail</a>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
              <div class="card card-stats">
                <div class="card-body ">
                  <div class="row">
                    <div class="col-5 col-md-4">
                      <div class="icon-big text-center icon-warning">
                        <i class="fa-solid fa-comments text-primary"></i>
                      </div>
                    </div>
                    <div class="col-7 col-md-8">
                      <div class="numbers">
                        <p class="card-category">Total Ulasan Anda</p>
                        <p class="card-title"><?php echo $total_ulasan ?>
                        <p>
                      </div>
                    </div>
                  </div>
                </div>
                <hr>
                <div class="card-footer ">
                  <a href="ulasan.php"><i class="fa-solid fa-circle-info"></i> Lihat detail</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-12">
            <h4 class="card-title m-4 text-primary"><strong>Buku paling banyak diminati</strong> </h4>
            <div class="row">
              <?php foreach ($buku_terpopuler as $buku): ?>
                <div class="col-lg-3 col-md-6 col-sm-6">
                  <div class="card card-stats">
                    <div class="card-body">
                      <div class="row">
                        <div class="col-5 col-md-4">
                          <div class="icon-big text-center">
                            <?php
                            // Check if sampul exists or use a fallback image
                            $cover_image = !empty($buku['sampul']) ? "../cover_buku/" . htmlspecialchars($buku['sampul']) : "../cover_buku/default.jpg";
                            ?>
                            <img src="<?php echo $cover_image; ?>" alt="Sampul Buku" width="100" style="border: solid 1px;" class="ml-4 mb-2 mt-4">
                          </div>
                        </div>
                        <div class="col-7 col-md-8 p-3">
                          <div class="numbers">
                            <p class="card-category"><strong><?php echo $buku['judul']; ?></strong></p>
                            <p class="card-category"><?php echo $buku['penerbit']; ?></p>
                            <p class="card-category"><?php echo $buku['nama_kategori']; ?></p>
                          </div>
                        </div>
                        <hr>
                        <div class="card-footer ">
                          <a href="buku.php?search=<?php echo $buku['judul']; ?>"><i class="fa-solid fa-circle-info"></i> Lihat detail</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>

      </div>
      <footer class="footer footer-black  footer-white ">
        <div class="container-fluid">
          <div class="row">
            <div class="credits ml-auto">
              <span class="copyright">
                © <script>
                  document.write(new Date().getFullYear())
                </script> PERPUSTAKAAN RANCAGE
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="../assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script><!-- Paper Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/assets-for-demo/js/demo.js
      demo.initChartsPages();
    });
  </script>
</body>

</html>