<?php
include "session.php";
include "../koneksi.php";

// Ambil user_id dari session
$email = $_SESSION['email'];
$query_user = "SELECT id FROM user WHERE email = '$email'";
$result_user = mysqli_query($koneksi, $query_user);
$user_data = mysqli_fetch_assoc($result_user);
$user_id = $user_data['id'];

// Ambil buku_id dari URL dan pastikan tidak kosong
$buku_id = isset($_GET['buku_id']) ? $_GET['buku_id'] : null;
if (!$buku_id) {
    echo "<script>alert('Buku ID tidak ditemukan!'); window.location.href = 'buku.php';</script>";
    exit;
}

// Proses form saat disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $rating = $_POST['rating'];
    $ulasan = $_POST['ulasan'];

    $query = "INSERT INTO ulasan_buku (user_id, buku_id, rating, ulasan) VALUES ('$user_id', '$buku_id', '$rating', '$ulasan')";
    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Ulasan berhasil ditambahkan!'); window.location.href = 'buku.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan ulasan.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open.svg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        PERPUSTAKAAN RANCAGE
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="../assets/demo/demo.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
    <style>
        .form-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 8px;
            background-color: #f9f9f9;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .form-title {
            text-align: center;
            font-size: 1.5em;
            color: #5a5a5a;
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card form-container">
                    <div class="card-header bg-primary text-white">
                        <h4 class="form-title">Tambah Ulasan</h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="mb-3">
                                <label for="rating" class="form-label">Rating:</label>
                                <select id="rating" name="rating" class="form-control" required>
                                    <option value="">Pilih Rating</option>
                                    <option value="1">1 - Sangat Buruk</option>
                                    <option value="2">2 - Buruk</option>
                                    <option value="3">3 - Biasa</option>
                                    <option value="4">4 - Baik</option>
                                    <option value="5">5 - Sangat Baik</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="ulasan" class="form-label">Ulasan:</label>
                                <textarea id="ulasan" name="ulasan" class="form-control" rows="4" placeholder="Tulis ulasan Anda..." required></textarea>
                            </div>
                            <button type="submit" class="btn btn-success">Kirim Ulasan</button>
                            <a href="buku.php" class="btn btn-danger">Batal</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS Files -->
    <script src="../assets/js/core/jquery.min.js"></script>
    <script src="../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap.min.js"></script>
</body>

</html>