<?php
include "session.php";
include "../koneksi.php";

// Set zona waktu sesuai dengan kebutuhan Anda
date_default_timezone_set("Asia/Jakarta"); // Contoh untuk zona waktu Jakarta

// Ambil user_id dari sesi login
$email = $_SESSION['email'];
$query_user = "SELECT id FROM user WHERE email = '$email'";
$result_user = mysqli_query($koneksi, $query_user);
$user_data = mysqli_fetch_assoc($result_user);
$user_id = $user_data['id'];

// Proses form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $keperluan = $_POST['keperluan'];
    $tgl = date('Y-m-d H:i:s');

    // Insert ke tabel kunjungan
    $query = "INSERT INTO kunjungan (user_id, keperluan, tgl) VALUES ('$user_id', '$keperluan', '$tgl')";
    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Kunjungan berhasil ditambahkan!'); window.location.href='kunjungan.php';</script>";
    } else {
        echo "<script>alert('Terjadi kesalahan, coba lagi.'); window.location.href='konfirmasi_kunjungan.php';</script>";
    }
}
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        PERPUSTAKAAN RANCAGE
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="../assets/demo/demo.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
    <style>
        .carousel-control-prev,
        .carousel-control-next {
            top: 50%;
            transform: translateY(50%);
        }
    </style>
</head>

<body class="">
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar" data-color="white" data-active-color="primary">
            <div class="logo">
                <a href="" class="simple-text logo-mini">
                    <div class="logo-image-mini">
                        <i class="fa-solid fa-book-open-reader text-primary"></i>
                    </div>
                </a>
                <a href="" class="h6 logo-normal text-primary" style="text-decoration: none;">
                    PERPUSTAKAAN RANCAGE
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li>
                        <a href="./dashboard.php">
                            <i class="fa-solid fa-house-chimney"></i>
                            <p>Beranda</p>
                        </a>
                    </li>
                    <li>
                        <a href="./buku.php">
                            <i class="fa-solid fa-book"></i>
                            <p>Daftar Buku</p>
                        </a>
                    </li>
                    <li>
                        <a href="./koleksibuku.php">
                            <i class="fa-solid fa-book-bookmark"></i>
                            <p>Koleksi Pribadi</p>
                        </a>
                    </li>
                    <li>
                        <a href="./peminjaman.php">
                            <i class="fa-solid fa-clock-rotate-left"></i>
                            <p>Histori Peminjaman</p>
                        </a>
                    </li>
                    <li class="active">
                        <a href="./kunjungan.php">
                            <i class="fa-solid fa-person-walking-arrow-right"></i>
                            <p>Histori Kunjungan</p>
                        </a>
                    </li>
                    <li>
                        <a href="./ulasan.php">
                            <i class="fa-solid fa-comments"></i>
                            <p>Ulasan Anda</p>
                        </a>
                    </li>
                    <li>
                        <a href="./user.php">
                            <i class="fa-solid fa-user"></i>
                            <p>Profile</p>
                        </a>
                    </li>
                    <li>
                        <a href="./terms.php">
                            <i class="fa-solid fa-circle-info"></i>
                            <p>Syarat & Ketentuan</p>
                        </a>
                    </li>
                    <hr>
                    <li>
                        <a href="./logout.php" class="text-danger" onclick="return confirm('Apakah Anda yakin ingin Logout?')">
                            <i class="fa-solid fa-arrow-right-from-bracket text-danger"></i>
                            <p>Logout</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Main Panel -->
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <a class="navbar-brand" href="javascript:;">Histori Kunjungan Anda</a>
                    </div>
                </div>
            </nav>
            <!-- End Navbar -->

            <div class="content">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-body">
                                    <form method="POST">
                                        <div class="form-group">
                                            <label for="keperluan">Keperluan</label>
                                            <select name="keperluan" id="keperluan" class="form-control" required>
                                                <option value="" disabled selected>Pilih Keperluan</option>
                                                <option value="membaca buku">Membaca Buku</option>
                                                <option value="meminjam buku">Meminjam Buku</option>
                                                <option value="mengembalikan buku">Mengembalikan Buku</option>
                                                <option value="keperluan lain">Keperluan Lain</option>
                                            </select>
                                        </div>
                                        <button type="submit" class="btn btn-primary btn-block" onclick="return confirm('Apakah Anda yakin ingin berkunjung hari ini?');">Konfirmasi</button>
                                    </form>
                                    <a href="kunjungan.php" class="btn btn-danger p-1">Batal</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="footer footer-black  footer-white ">
                <div class="container-fluid">
                    <div class="row">
                        <div class="credits ml-auto">
                            <span class="copyright">
                                © <script>
                                    document.write(new Date().getFullYear())
                                </script> PERPUSTAKAAN RANCAGE
                            </span>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    </div>
</body>

</html>