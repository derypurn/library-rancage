<?php
session_start();
include "../koneksi.php";

$email = $_SESSION['email'];
$query_user = "SELECT id FROM user WHERE email = '$email'";
$result_user = mysqli_query($koneksi, $query_user);
$user_data = mysqli_fetch_assoc($result_user);
$user_id = $user_data['id'];

// Cek apakah buku_id ada di URL
if (isset($_GET['buku_id'])) {
    $buku_id = $_GET['buku_id'];

    // Query untuk menghapus koleksi pribadi berdasarkan user_id dan buku_id
    $query = "DELETE FROM koleksipribadi WHERE user_id = '$user_id' AND buku_id = '$buku_id'";
    $result = mysqli_query($koneksi, $query);

    // Cek apakah query berhasil dijalankan
    if ($result && mysqli_affected_rows($koneksi) > 0) {
        echo "<script>alert('Koleksi buku berhasil dihapus.'); window.location.href = 'koleksibuku.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus koleksi buku.'); window.location.href = 'koleksibuku.php';</script>";
    }
} else {
    // Redirect jika buku_id tidak ditemukan
    header("Location: koleksibuku.php");
    exit();
}
