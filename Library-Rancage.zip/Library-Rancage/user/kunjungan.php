<?php
include "session.php";
include "../koneksi.php";

// Ambil user_id dari sesi login
$email = $_SESSION['email'];
$query_user = "SELECT id FROM user WHERE email = '$email'";
$result_user = mysqli_query($koneksi, $query_user);
$user_data = mysqli_fetch_assoc($result_user);
$user_id = $user_data['id'];

// Ambil data kunjungan sesuai user_id
$query = "SELECT id, keperluan, tgl FROM kunjungan WHERE user_id = '$user_id' ORDER BY tgl DESC";
$result = mysqli_query($koneksi, $query);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        PERPUSTAKAAN RANCAGE
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="../assets/demo/demo.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
    <style>
        .carousel-control-prev,
        .carousel-control-next {
            top: 50%;
            transform: translateY(50%);
        }
    </style>
</head>

<body class="">
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar" data-color="white" data-active-color="primary">
            <div class="logo">
                <a href="" class="simple-text logo-mini">
                    <div class="logo-image-mini">
                        <i class="fa-solid fa-book-open-reader text-primary"></i>
                    </div>
                </a>
                <a href="" class="h6 logo-normal text-primary" style="text-decoration: none;">
                    PERPUSTAKAAN RANCAGE
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li>
                        <a href="./dashboard.php">
                            <i class="fa-solid fa-house-chimney"></i>
                            <p>Beranda</p>
                        </a>
                    </li>
                    <li>
                        <a href="./buku.php">
                            <i class="fa-solid fa-book"></i>
                            <p>Daftar Buku</p>
                        </a>
                    </li>
                    <li>
                        <a href="./koleksibuku.php">
                            <i class="fa-solid fa-book-bookmark"></i>
                            <p>Koleksi Pribadi</p>
                        </a>
                    </li>
                    <li>
                        <a href="./peminjaman.php">
                            <i class="fa-solid fa-clock-rotate-left"></i>
                            <p>Histori Peminjaman</p>
                        </a>
                    </li>
                    <li class="active">
                        <a href="./kunjungan.php">
                            <i class="fa-solid fa-person-walking-arrow-right"></i>
                            <p>Histori Kunjungan</p>
                        </a>
                    </li>
                    <li>
                        <a href="./ulasan.php">
                            <i class="fa-solid fa-comments"></i>
                            <p>Ulasan Anda</p>
                        </a>
                    </li>
                    <li>
                        <a href="./user.php">
                            <i class="fa-solid fa-user"></i>
                            <p>Profile</p>
                        </a>
                    </li>
                    <li>
                        <a href="./terms.php">
                            <i class="fa-solid fa-circle-info"></i>
                            <p>Syarat & Ketentuan</p>
                        </a>
                    </li>
                    <hr>
                    <li>
                        <a href="./logout.php" class="text-danger" onclick="return confirm('Apakah Anda yakin ingin Logout?')">
                            <i class="fa-solid fa-arrow-right-from-bracket text-danger"></i>
                            <p>Logout</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Main Panel -->
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <a class="navbar-brand" href="javascript:;">Histori Kunjungan Anda</a>
                    </div>
                </div>
            </nav>
            <!-- End Navbar -->

            <div class="content">
                <div class="container">
                    <div class="row">
                        <div class="col-12 mb-4">
                            <a href="konfirmasi_kunjungan.php" class="btn btn-primary">Tambah Kunjungan</a>
                        </div>
                        <?php if (mysqli_num_rows($result) > 0): ?>
                            <?php $no = 1; // Inisialisasi nomor urut 
                            ?>
                            <?php while ($data = mysqli_fetch_assoc($result)): ?>
                                <div class="col-md-12 col-lg-6 mb-4">
                                    <div class="card">
                                        <div class="card-body">
                                            <p class="card-text">
                                                <strong><?php echo $no; ?>. &emsp;Keperluan:</strong> <?php echo htmlspecialchars($data['keperluan']); ?><br>
                                                <strong> &emsp; &emsp;Tanggal:</strong> <?php echo htmlspecialchars($data['tgl']); ?><br>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <?php $no++; // Increment nomor urut 
                                ?>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="col-12">
                                <p class="text-center mt-5">Belum ada kunjungan yang tercatat.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
            <footer class="footer footer-black  footer-white ">
                <div class="container-fluid">
                    <div class="row">
                        <div class="credits ml-auto">
                            <span class="copyright">
                                © <script>
                                    document.write(new Date().getFullYear())
                                </script> PERPUSTAKAAN RANCAGE
                            </span>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    </div>
</body>

</html>