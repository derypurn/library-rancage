<?php
include "session.php"; // Memastikan user sudah login
include "../koneksi.php"; // Koneksi ke database

$email = $_SESSION['email']; // Ambil email dari session

// Cek apakah email ada di session
if (!isset($email)) {
    die("Anda belum login.");
}

// Query untuk mengambil data pengguna
$query_user = "SELECT * FROM user WHERE email = ?";
$stmt = $koneksi->prepare($query_user);
$stmt->bind_param("s", $email); // Bind parameter email
$stmt->execute(); // Eksekusi query
$result_user = $stmt->get_result(); // Ambil hasil

// Cek jika ada pengguna yang ditemukan
if ($result_user->num_rows > 0) {
    $userData = $result_user->fetch_assoc(); // Ambil data pengguna
} else {
    die("Pengguna tidak ditemukan.");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        PERPUSTAKAAN RANCAGE
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="../assets/demo/demo.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
    <script>
        function toggleEdit() {
            var inputs = document.querySelectorAll('.form-control');
            var editButton = document.getElementById('editButton');
            var saveButton = document.getElementById('saveButton');
            var fotoInput = document.getElementById('foto'); // Ambil input file foto
            var isReadonly = inputs[0].readOnly;

            inputs.forEach(function(input, index) {
                if (index !== 5) { // Skip level (indeks 5)
                    input.readOnly = !isReadonly; // Ubah status readonly
                }
            });

            // Atur status disabled pada input file foto
            fotoInput.disabled = !isReadonly;

            // Ubah teks tombol sesuai status edit
            if (isReadonly) {
                editButton.innerText = 'X';
                saveButton.disabled = false; // Aktifkan tombol simpan
            } else {
                editButton.innerText = 'EDIT';
                saveButton.disabled = true; // Nonaktifkan tombol simpan
            }
        }
    </script>
</head>

<body class="">
    <div class="wrapper ">
        <div class="sidebar" data-color="white" data-active-color="primary">
            <div class="logo">
                <a href="" class="simple-text logo-mini">
                    <div class="logo-image-mini">
                        <i class="fa-solid fa-book-open-reader text-primary"></i>
                    </div>
                </a>
                <a href="" class="h6 logo-normal text-primary" style="text-decoration: none;">
                    PERPUSTAKAAN RANCAGE

                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li>
                        <a href="./dashboard.php">
                            <i class="fa-solid fa-house-chimney"></i>
                            <p>Beranda</p>
                        </a>
                    </li>
                    <li>
                        <a href="./buku.php">
                            <i class="fa-solid fa-book"></i>
                            <p>Daftar Buku</p>
                        </a>
                    </li>
                    <li>
                        <a href="./koleksibuku.php">
                            <i class="fa-solid fa-book-bookmark"></i>
                            <p>Koleksi Pribadi</p>
                        </a>
                    </li>
                    <li>
                        <a href="./peminjaman.php">
                            <i class="fa-solid fa-clock-rotate-left"></i>
                            <p>Histori Peminjaman</p>
                        </a>
                    </li>
                    <li>
                        <a href="./kunjungan.php">
                            <i class="fa-solid fa-person-walking-arrow-right"></i>
                            <p>Histori Kunjungan</p>
                        </a>
                    </li>
                    <li>
                    <li class="active">
                        <a href="./ulasan.php">
                            <i class="fa-solid fa-comments"></i>
                            <p>Ulasan Anda</p>
                        </a>
                    </li>
                    <li>
                        <a href="./user.php">
                            <i class="fa-solid fa-user"></i>
                            <p>Profile</p>
                        </a>
                    </li>
                    <li>
                        <a href="./terms.php">
                            <i class="fa-solid fa-circle-info"></i>
                            <p>Syarat & Ketentuan</p>
                        </a>
                    </li>
                    <hr>
                    <li>
                        <a href="./logout.php" class="text-danger" onclick="return confirm('Apakah Anda yakin ingin Logout?')">
                            <i class="fa-solid fa-arrow-right-from-bracket text-danger"></i>
                            <p>Logout</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
                <div class="container-fluid">
                    <div class="navbar-wrapper">
                        <div class="navbar-toggle">
                            <button type="button" class="navbar-toggler">
                                <span class="navbar-toggler-bar bar1"></span>
                                <span class="navbar-toggler-bar bar2"></span>
                                <span class="navbar-toggler-bar bar3"></span>
                            </button>
                        </div>
                        <a class="navbar-brand" href="javascript:;">Ulasan</a>
                    </div>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                        <span class="navbar-toggler-bar navbar-kebab"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <form>
                            <div class="input-group no-border">
                                <input type="text" value="" class="form-control" placeholder="Search...">
                                <div class="input-group-append">
                                    <div class="input-group-text">
                                        <i class="nc-icon nc-zoom-split"></i>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link btn-magnify" href="javascript:;">
                                    <i class="nc-icon nc-layout-11"></i>
                                    <p>
                                        <span class="d-lg-none d-md-block">Stats</span>
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item btn-rotate dropdown">
                                <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="nc-icon nc-bell-55"></i>
                                    <p>
                                        <span class="d-lg-none d-md-block">Some Actions</span>
                                    </p>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <a class="dropdown-item" href="#">Something else here</a>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn-rotate" href="javascript:;">
                                    <i class="nc-icon nc-settings-gear-65"></i>
                                    <p>
                                        <span class="d-lg-none d-md-block">Account</span>
                                    </p>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- End Navbar -->
            <div class="content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Profil Pengguna</h4>
                            </div>
                            <div class="card-body">
                                <form action="update_profile.php" method="POST" id="profileForm" enctype="multipart/form-data">
                                    <div class="form-group text-center">
                                        <img src="../foto_user/<?php echo htmlspecialchars($userData['foto'] ?? 'default.jpg'); ?>"
                                            alt="Foto Profil"
                                            class="img-thumbnail mb-2"
                                            width="150" />
                                        <input type="file" class="form-control" id="foto" name="foto" accept="image/*">
                                    </div>
                                    <div class="form-group">
                                        <label for="username">Username:</label>
                                        <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($userData['username']); ?>" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="namalengkap">Nama Lengkap:</label>
                                        <input type="text" class="form-control" id="namalengkap" name="namalengkap" value="<?php echo htmlspecialchars($userData['namalengkap']); ?>" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email:</label>
                                        <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($userData['email']); ?>" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="alamat">Alamat:</label>
                                        <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo htmlspecialchars($userData['alamat']); ?>" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="level">Level:</label>
                                        <input type="text" class="form-control" id="level" name="level" value="<?php echo htmlspecialchars($userData['level']); ?>" readonly>
                                    </div>
                                    <button type="button" class="btn btn-warning" id="editButton" onclick="toggleEdit()">EDIT</button>
                                    <button type="submit" class="btn btn-primary mt-3" id="saveButton" disabled>Simpan</button>
                                </form>
                            </div>
                        </div>
                        <footer class="footer">
                            <div class="container-fluid">
                                <div class="credits ml-auto">
                                    © <?php echo date("Y"); ?> PERPUSTAKAAN RANCAGE
                                </div>
                            </div>
                        </footer>
                    </div>
                </div>
            </div>
            <footer class="footer footer-black  footer-white ">
                <div class="container-fluid">
                    <div class="row">
                        <div class="credits ml-auto">
                            <span class="copyright">
                                © <script>
                                    document.write(new Date().getFullYear())
                                </script> PERPUSTAKAAN RANCAGE
                            </span>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <!--   Core JS Files   -->
    <script src="../assets/js/core/jquery.min.js"></script>
    <script src="../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap.min.js"></script>
    <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
    <!--  Google Maps Plugin    -->
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
    <!-- Chart JS -->
    <script src="../assets/js/plugins/chartjs.min.js"></script>
    <!--  Notifications Plugin    -->
    <script src="../assets/js/plugins/bootstrap-notify.js"></script>
    <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="../assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script><!-- Paper Dashboard DEMO methods, don't include it in your project! -->
    <script src="../assets/demo/demo.js"></script>
</body>

</html>