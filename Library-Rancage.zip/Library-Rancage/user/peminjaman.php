<?php
include "../koneksi.php";
include "session.php";

$email = $_SESSION['email'];
$query_user = "SELECT id FROM user WHERE email = '$email'";
$result_user = mysqli_query($koneksi, $query_user);
$user_data = mysqli_fetch_assoc($result_user);
$user_id = $user_data['id'];

$query = "SELECT peminjaman.buku_id, peminjaman.tgl_pinjam, peminjaman.batas_pinjam, peminjaman.status, 
                 peminjaman.tgl_kembali, buku.judul, buku.penulis, buku.penerbit, buku.tahun_terbit, 
                 buku.sampul, kategoribuku.nama_kategori AS kategori 
          FROM peminjaman 
          JOIN buku ON peminjaman.buku_id = buku.id 
          JOIN kategoribuku_relasi ON buku.id = kategoribuku_relasi.buku_id 
          JOIN kategoribuku ON kategoribuku_relasi.kategori_id = kategoribuku.id 
          WHERE peminjaman.user_id = '$user_id'";

$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open-reader.svg">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    PERPUSTAKAAN RANCAGE
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <link href="../assets/demo/demo.css" rel="stylesheet" />
  <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
</head>

<body class="">
  <div class="wrapper">
    <!-- Sidebar -->
    <div class="sidebar" data-color="white" data-active-color="primary">
      <div class="logo">
        <a href="" class="simple-text logo-mini">
          <div class="logo-image-mini">
            <i class="fa-solid fa-book-open-reader text-primary"></i>
          </div>
        </a>
        <a href="" class="h6 logo-normal text-primary" style="text-decoration: none;">
          PERPUSTAKAAN RANCAGE

        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li>
            <a href="./dashboard.php">
              <i class="fa-solid fa-house-chimney"></i>
              <p>Beranda</p>
            </a>
          </li>
          <li>
            <a href="./buku.php">
              <i class="fa-solid fa-book"></i>
              <p>Daftar Buku</p>
            </a>
          </li>
          <li>
            <a href="./koleksibuku.php">
              <i class="fa-solid fa-book-bookmark"></i>
              <p>Koleksi Pribadi</p>
            </a>
          </li>
          <li class="active">
            <a href="./peminjaman.php">
              <i class="fa-solid fa-clock-rotate-left"></i>
              <p>Histori Peminjaman</p>
            </a>
          </li>
          <li>
            <a href="./kunjungan.php">
              <i class="fa-solid fa-person-walking-arrow-right"></i>
              <p>Histori Kunjungan</p>
            </a>
          </li>
          <li>
          <li>
            <a href="./ulasan.php">
              <i class="fa-solid fa-comments"></i>
              <p>Ulasan Anda</p>
            </a>
          </li>
          <li>
            <a href="./user.php">
              <i class="fa-solid fa-user"></i>
              <p>Profile</p>
            </a>
          </li>
          <li>
            <a href="./terms.php">
              <i class="fa-solid fa-circle-info"></i>
              <p>Syarat & Ketentuan</p>
            </a>
          </li>
          <hr>
          <li>
            <a href="./logout.php" class="text-danger" onclick="return confirm('Apakah Anda yakin ingin Logout?')">
              <i class="fa-solid fa-arrow-right-from-bracket text-danger"></i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </div>
    </div>

    <!-- Main Panel -->
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;">Histori Peminjaman</a>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->

      <div class="content">
        <div class="container">
          <div class="row">
            <?php if (mysqli_num_rows($result) > 0) : ?>
              <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                <?php
                // Menghitung denda berdasarkan batas pinjam dan tanggal saat ini
                if (!empty($row['batas_pinjam'])) {
                  $batasPinjam = new DateTime($row['batas_pinjam']);
                  $tanggalHariIni = new DateTime();
                  if ($tanggalHariIni > $batasPinjam) {
                    $selisihHari = $tanggalHariIni->diff($batasPinjam)->days;
                    $denda = $selisihHari * 1000;
                  } else {
                    $denda = 0;
                  }
                } else {
                  $denda = 0;
                }
                ?>
                <div class="col-md-12 col-lg-8 mb-4">
                  <div class="card">
                    <div class="card-body">
                      <!-- Menampilkan Sampul Buku -->
                      <img src="../cover_buku/<?php echo htmlspecialchars($row['sampul']); ?>" alt="Sampul Buku" width="100" style="border: solid 1px;" class="ml-4 mb-2 mt-4">
                      <h5 class="card-title"><?php echo htmlspecialchars($row['judul']); ?></h5>
                      <hr>
                      <p class="card-text">
                        <strong>Kategori:</strong> <?php echo htmlspecialchars($row['kategori']); ?><br>
                        <strong>Penulis:</strong> <?php echo htmlspecialchars($row['penulis']); ?><br>
                        <strong>Penerbit:</strong> <?php echo htmlspecialchars($row['penerbit']); ?><br>
                        <strong>Tahun Terbit:</strong> <?php echo htmlspecialchars($row['tahun_terbit']); ?><br>
                        <hr>
                        <strong>Tanggal Pinjam:</strong> <?php echo htmlspecialchars($row['tgl_pinjam']); ?><br>
                        <strong>Batas Pinjam:</strong> <?php echo htmlspecialchars($row['batas_pinjam']); ?><br>
                        <strong>Status:</strong>
                        <span class="<?php echo ($row['status'] === 'dipinjam') ? 'text-danger' : 'text-success'; ?>">
                          <?php echo ucfirst(htmlspecialchars($row['status'])); ?>
                        </span>
                        <hr>
                        <strong>Denda:</strong><b class="text-danger"> Rp.<?php echo number_format($denda, 0, ',', '.'); ?></b><br>
                      </p>

                      <?php if ($row['status'] === 'dikembalikan') : ?>
                        <a href="tambah_ulasan.php?buku_id=<?php echo htmlspecialchars($row['buku_id']); ?>" class="btn btn-warning mt-3 rounded-pill">
                          <i class="nc-icon nc-chat-33"></i> Ulasan
                        </a>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>

              <?php endwhile; ?>
            <?php else : ?>
              <div class="col-12">
                <p class="text-center mt-5">Belum ada peminjaman Anda, silakan meminjam buku.</p>
              </div>
            <?php endif; ?>
          </div>
        </div>


        <footer class="footer footer-black  footer-white ">
          <div class="container-fluid">
            <div class="row">
              <div class="credits ml-auto">
                <span class="copyright">
                  © <script>
                    document.write(new Date().getFullYear())
                  </script> PERPUSTAKAAN RANCAGE
                </span>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>

    <!-- Core JS Files -->
    <script src="../assets/js/core/jquery.min.js"></script>
    <script src="../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap.min.js"></script>
</body>

</html>