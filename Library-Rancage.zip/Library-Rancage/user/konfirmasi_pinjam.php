<?php
session_start(); // Pastikan session dimulai
include "../koneksi.php";
include "session.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Pastikan user_id diambil dari session
    if (!isset($_SESSION['user_id'])) {
        die("User ID tidak ditemukan. Silakan login terlebih dahulu.");
    }

    $user_id = $_SESSION['user_id']; // Ambil user_id dari session
    $buku_id = $_POST['buku_id']; // Dapatkan buku_id dari POST
    $tgl_pinjam = date("Y-m-d"); // Dapatkan tanggal pinjam
    $batas_pinjam = date("Y-m-d", strtotime("+7 days")); // Hitung batas pinjam

    // Insert data ke tabel peminjaman
    $query = "INSERT INTO peminjaman (user_id, buku_id, tgl_pinjam, batas_pinjam, tgl_kembali, status) 
              VALUES ('$user_id', '$buku_id', '$tgl_pinjam', '$batas_pinjam', NULL, 'dipinjam')";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Peminjaman berhasil ditambahkan!'); window.location.href='peminjaman.php';</script>";
    } else {
        echo "<script>alert('Gagal menambah data peminjaman.'); window.history.back();</script>";
    }
}
