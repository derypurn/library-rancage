<?php
include "session.php";
include "../koneksi.php";

// Ambil user_id dari session
$email = $_SESSION['email'];
$query_user = "SELECT id FROM user WHERE email = '$email'";
$result_user = mysqli_query($koneksi, $query_user);
$user_data = mysqli_fetch_assoc($result_user);
$user_id = $user_data['id'];

// Ambil ulasan_id dari URL
$ulasan_id = isset($_GET['id']) ? $_GET['id'] : null;
if (!$ulasan_id) {
    echo "<script>alert('ID ulasan tidak ditemukan!'); window.location.href = 'ulasan.php';</script>";
    exit;
}

// Jika form disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ulasan_baru = mysqli_real_escape_string($koneksi, $_POST['ulasan']);
    $rating_baru = (int) $_POST['rating'];

    // Update ulasan dan rating berdasarkan ulasan_id dan user_id
    $query = "UPDATE ulasan_buku SET ulasan = '$ulasan_baru', rating = '$rating_baru' WHERE id = '$ulasan_id' AND user_id = '$user_id'";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Ulasan berhasil diperbarui.'); window.location.href = 'ulasan.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui ulasan.'); window.location.href = 'ulasan.php';</script>";
    }
} else {
    // Ambil data ulasan yang akan diedit
    $query = "SELECT ulasan, rating FROM ulasan_buku WHERE id = '$ulasan_id' AND user_id = '$user_id'";
    $result = mysqli_query($koneksi, $query);

    if (mysqli_num_rows($result) == 1) {
        $data = mysqli_fetch_assoc($result);
    } else {
        echo "<script>alert('Data ulasan tidak ditemukan atau Anda tidak memiliki izin untuk mengedit ulasan ini.'); window.location.href = 'ulasan.php';</script>";
        exit;
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/css/fontawesome/svgs/solid/book-open.svg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        PERPUSTAKAAN RANCAGE
    </title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
    <link href="../assets/demo/demo.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/fontawesome/css/all.min.css">
    <style>
        .form-container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 8px;
            background-color: #f9f9f9;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .form-title {
            text-align: center;
            font-size: 1.5em;
            color: #5a5a5a;
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card form-container">
                    <div class="card-header m-0 bg-primary text-white">
                        <h6 class="form-title text-white">Edit Ulasan</h6>
                    </div>
                    <div class="card-body">
                        <form method="post" action="">
                            <label for="ulasan">Ulasan:</label>
                            <textarea name="ulasan" id="ulasan" class="form-control" required><?= htmlspecialchars($data['ulasan']) ?></textarea>
                            <br>

                            <label for="rating">Rating:</label>
                            <select name="rating" id="rating" class="form-control" required>
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <option value="<?= $i ?>" <?= $data['rating'] == $i ? 'selected' : '' ?>><?= $i ?></option>
                                <?php endfor; ?>
                            </select>
                            <br>

                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                            <a href="ulasan.php" class="btn btn-danger">Batal</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Core JS Files -->
    <script src="../assets/js/core/jquery.min.js"></script>
    <script src="../assets/js/core/popper.min.js"></script>
    <script src="../assets/js/core/bootstrap.min.js"></script>
</body>

</html>